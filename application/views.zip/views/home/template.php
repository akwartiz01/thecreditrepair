<?php

$this->load->view($theme . '/include/header');

$this->load->view($theme . '/' . $page);

$this->load->view($theme . '/include/footer');
