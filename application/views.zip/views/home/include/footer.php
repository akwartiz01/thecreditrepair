    <!-- [ testimonial ] end -->
    <!-- [ Footer ] start -->
    <footer class="site-footer bg-gray-100">
        <div class="container">
            <div class="footer-row">
                <div class="ftr-col cmp-detail">
                    <div class="footer-logo mb-3">
                        <a href="#">
                            <img src="<?php echo base_url(); ?>assets/images/logo.png" alt="logo"
                                style="filter: drop-shadow(2px 3px 7px #011C4B);">
                        </a>
                    </div>
                    <p>
                        The Credit Repair Xperts is dedicated to helping you improve your credit score and achieve financial freedom. Our team of experts works tirelessly to provide you with the best service and support.

                    </p>

                </div>
                <!-- <div class="ftr-col">
                    <ul class="list-unstyled">

                        <li><a href="">About Us</a></li>
                        <li><a href="">Terms and Conditions</a></li>
                        <li><a href="">Refund Policy</a></li>

                    </ul>
                </div> -->
                <div class="ftr-col">
                    <ul class="list-unstyled">
                    </ul>
                </div>

                <div class="ftr-col ftr-subscribe">
                    <h2>Contact Us</h2>
                    <p>Call us : (856) 515-6408</p>
                    <p>Address : 309 Fellowship Road Suite 200 - #693 Mt. Laurel, NJ 08054</p>
                </div>
            </div>
        </div>
        <div class="border-top border-dark text-center p-2">


            <p class="mb-0"> Copyright &copy;
                <?php echo date('Y'); ?> The Credit Repair Xperts - All Rights Reserved.
            </p>
        </div>
    </footer>
    <!-- [ Footer ] end -->
    <!-- Required Js -->

    <script src="<?php echo base_url(); ?>Landing_page/assets/js/plugins/popper.min.js"></script>
    <script src="<?php echo base_url(); ?>Landing_page/assets/js/plugins/bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>Landing_page/assets/js/plugins/feather.min.js"></script>

    <script src="<?php echo base_url(); ?>Landing_page/public/custom/js/jquery.min.js"></script>
    <script src="<?php echo base_url(); ?>Landing_page/public/assets/js/plugins/bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>Landing_page/public/custom/js/custom.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
        // Start [ Menu hide/show on scroll ]
        let ost = 0;
        document.addEventListener("scroll", function() {
            let cOst = document.documentElement.scrollTop;
            if (cOst == 0) {
                document.querySelector(".navbar").classList.add("top-nav-collapse");
            } else if (cOst > ost) {
                document.querySelector(".navbar").classList.add("top-nav-collapse");
                document.querySelector(".navbar").classList.remove("default");
            } else {
                document.querySelector(".navbar").classList.add("default");
                document
                    .querySelector(".navbar")
                    .classList.remove("top-nav-collapse");
            }
            ost = cOst;
        });
        // End [ Menu hide/show on scroll ]

        var scrollSpy = new bootstrap.ScrollSpy(document.body, {
            target: "#navbar-example",
        });
        feather.replace();


        $(document).ready(function() {
            $('.tox-notifications-container').addClass('d-none')
        });
    </script>

    <script>
        function subscribe(subscriptionId, price) {
            $.ajax({
                url: "<?php echo base_url('subscribe'); ?>",
                type: "POST",
                data: {
                    id: subscriptionId,
                    price: price
                },
                success: function(response) {
                    window.location.href = "<?php echo base_url('registration'); ?>";
                },
                error: function(xhr, status, error) {
                    console.error("Subscription failed: " + error);
                }
            });
        }
    </script>

    </body>

    </html>