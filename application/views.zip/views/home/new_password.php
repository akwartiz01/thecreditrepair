<!DOCTYPE html>
<html lang="en">
  
 
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Credit Repair Xperts</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/vendors/css/vendor.bundle.base.css">
    <!-- endinject -->
   
    <!-- Layout styles -->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/demo_3/style.css">
    <!-- End layout styles -->
    <link rel="shortcut icon" href="<?php echo base_url(); ?>assets/images/logo.png" />
	<style>
	
    .auth form .form-group {
        margin-bottom: 1.0rem !important;
    }

    @media only screen and (max-width: 768px) {
      .login-half-bg{
        display: none !important;
      }
    }
 </style>
  </head>
  <body>
    <div class="container-scroller">
      <div class="container-fluid page-body-wrapper full-page-wrapper">
        <div class="content-wrapper d-flex align-items-stretch auth auth-img-bg">
          <div class="row flex-grow">
            <div class="col-lg-6 d-flex justify-content-center">
              <div class="auth-form-transparent text-left p-3">
                <a href="<?php echo base_url();?>"><div class="brand-logo">
                  <img src="<?php echo base_url();?>assets/images/logo.png" alt="logo">
                </div> 
                </a>
                <?php 
                if(!empty($msg2) && $status2 == 'true'){ ?>
                 <h4 style="color: green;"><?php echo $msg2;?></h4>
                <?php  } ?>
                <?php 
                if(!empty($msg) && $status == 'false'){ ?>
                 <h4 style="color: red;"><?php echo $msg;?></h4>
                <?php  } ?>
                <form class="pt-3" action="" method="POST" enctype="multipart/form-data" >
                <input type="hidden" name="UserId" value="<?php echo $id;?>">

 
                  <div class="form-group">
                    <label for="exampleInputPassword">Password</label>
                    <div class="input-group">
                      <div class="input-group-prepend bg-transparent">
                        <span class="input-group-text bg-transparent border-right-0">
                          <i class="mdi mdi-lock-outline text-primary"></i>
                        </span>
                      </div>
                      <input type="password" class="form-control form-control-lg border-left-0" id="new_password" name="new_password" placeholder="Password">
                      <div class="form-error"><?php echo form_error('new_password'); ?></div>
                    </div>
                  </div>                 

                   <div class="form-group">
                    <label for="exampleInputPassword">Confirm Password</label>
                    <div class="input-group">
                      <div class="input-group-prepend bg-transparent">
                        <span class="input-group-text bg-transparent border-right-0">
                          <i class="mdi mdi-lock-outline text-primary"></i>
                        </span>
                      </div>
                      <input type="password" class="form-control form-control-lg border-left-0" id="re_password" name="re_password" placeholder="Password">
                      <div class="form-error"><?php echo form_error('re_password'); ?></div>
                    </div>
                  </div>

                  <div class="my-3">
                    <a ><!-- RESET --></a>
                    <button type="submit" class="btn btn-block btn-gradient-primary btn-lg font-weight-medium auth-form-btn" >RESET</button>
                  </div>
                  <div class="text-center mt-4 font-weight-light"> You have account? <a href="<?php echo base_url();?>" class="text-primary">Login</a>
                  </div>
                </form>
              </div>
            </div>
            <div class="col-lg-6 login-half-bg d-flex flex-row">
              <p class="text-white font-weight-medium text-center flex-grow align-self-end">Copyright &copy; <?php echo date("Y"); ?> All rights reserved.</p>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="<?php echo base_url();?>assets/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="<?php echo base_url();?>assets/js/off-canvas.js"></script>
    <script src="<?php echo base_url();?>assets/js/hoverable-collapse.js"></script>
    <script src="<?php echo base_url();?>assets/js/misc.js"></script>
    <script src="<?php echo base_url();?>assets/js/settings.js"></script>
    <script src="<?php echo base_url();?>assets/js/todolist.js"></script>

    <!-- endinject -->
  </body>

</html>