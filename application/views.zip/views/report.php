<?php echo $res; ?>

<!-- <form
		method="post"
		action="<?php echo base_url();?>index.php/FinalScrap"
		id="final_form"
		name="final_form"
		style="display: none"
>
	<input type="hidden" value="<?php echo $res["client_id"]?>" name="client_id">
</form>
 -->