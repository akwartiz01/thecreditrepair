<?php

if (isset($this->session->userdata['user_type']) && $this->session->userdata['user_type'] == 'super' || $this->session->userdata['user_type'] == 'emp') {

    $this->load->view($theme . '/include/header');

    $this->load->view($theme . '/include/navbar');

    $this->load->view($theme . '/include/sidebar');

    $this->load->view($page);

    $this->load->view($theme . '/include/footer');
} else {

    redirect(base_url());
}
