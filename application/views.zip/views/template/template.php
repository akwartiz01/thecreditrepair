<?php
$this->load->view('template/header');

	echo $content;


$this->load->view('template/footer');
?>