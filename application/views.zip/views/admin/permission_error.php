<style>
	footer{
		display: none;
	}
	.container-scroller .page-body-wrapper{
		background: #fff;
	}
	.page-body-wrapper h2{
		text-align: center;
	}
</style>
<div class="container-fluid page-body-wrapper">
    <div class="main-panel">
      <div class="content-wrapper">
         
        <div class="card">
          <div class="card-body">
            <div class="row">
              <div class="col-12"> 
				<h2>Oops! You do not have permission to access this page.</h2>
			  </div>
            </div>

        </div>
    </div>
</div>
</div>
</div>