<link rel="stylesheet" href="<?php echo base_url(); ?>assets/assets/css/bootstrap-datetimepicker.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<style>
  #createEventModal .modal-content {
    width: 80%;
    background: #fff;
    margin: auto;
  }

  #createEventModal .modal-header {
    padding: 25px 26px 10px;
    margin-bottom: 20px;

  }

  .event_calendar {
    padding-left: 20px !important;
    padding-right: 20px !important;
  }

  /* Styling the input field */
  .datepicker_time input {
    border: 1px solid #ced4da;
    border-radius: 4px;
    padding: 10px;
    font-size: 16px;
    color: #495057;
    width: 100%;
  }

  /* Styling the datepicker widget */
  .bootstrap-datetimepicker-widget {
    background-color: #fff;
    border: 1px solid #ced4da;
    border-radius: 8px;
    box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
    padding: 10px;
  }

  /* Styling the header (month and year) */
  .bootstrap-datetimepicker-widget .datepicker-switch {
    background-color: #007bff;
    color: #fff;
    padding: 10px;
    font-weight: bold;
    border-radius: 8px 8px 0 0;
    text-align: center;
    margin-bottom: 10px;
  }

  /* Styling the days of the week */
  .bootstrap-datetimepicker-widget .dow {
    color: #007bff;
    font-weight: bold;
  }

  /* Styling individual day cells */
  .bootstrap-datetimepicker-widget td.day {
    padding: 10px;
    border-radius: 4px;
    transition: background-color 0.2s, color 0.2s;
    cursor: pointer;
  }

  /* Styling selected and hovered days */
  .bootstrap-datetimepicker-widget td.active,
  .bootstrap-datetimepicker-widget td.active:hover,
  .bootstrap-datetimepicker-widget td.day:hover {
    background-color: #007bff;
    color: #fff;
  }

  /* Styling the navigation arrows */
  .bootstrap-datetimepicker-widget .prev,
  .bootstrap-datetimepicker-widget .next {
    color: #007bff;
    font-size: 18px;
    padding: 5px;
    transition: color 0.2s;
    cursor: pointer;
  }

  .bootstrap-datetimepicker-widget .prev:hover,
  .bootstrap-datetimepicker-widget .next:hover {
    color: #0056b3;
  }

  /* Styling for AM/PM switch */
  .bootstrap-datetimepicker-widget .timepicker-hour,
  .bootstrap-datetimepicker-widget .timepicker-minute,
  .bootstrap-datetimepicker-widget .timepicker-second,
  .bootstrap-datetimepicker-widget .timepicker-meridian {
    border: none;
    background-color: #f8f9fa;
    border-radius: 4px;
    padding: 5px;
    margin: 5px;
    cursor: pointer;
  }

  .bootstrap-datetimepicker-widget .timepicker-meridian {
    text-transform: uppercase;
  }

  /*  */
  .is-invalid {
    border-color: #dc3545;
  }

  .invalid-feedback {
    color: #dc3545;
    display: block;
    font-size: 14px !important;
  }

  /*  */

  /**** NEW STYLING ****/
  button.fc-button{
    color: black;
  }

  .fc td{
    border: 1px solid darkgray;
  }

  .fc .fc-button-group{
    border: 1px solid darkgray;
  }

  .fc button .fc-icon{
    color: darkgray;
  }
  /*END NEW STYLING*/
</style>
<div id="deletePopup" class="swal-overlay swal-overlay--show-modal" tabindex="-1" style="display: none;">
  <div id="deletePopupModal" class="swal-modal" role="dialog" aria-modal="true" style="display: none;">
    <input type="hidden" name="hiddenClientId" id="hiddenClientId" value="">
    <div class="swal-icon swal-icon--warning">
      <span class="swal-icon--warning__body">
        <span class="swal-icon--warning__dot"></span>
      </span>
    </div>
    <div class="swal-title" style="">Are you sure?</div>
    <div class="swal-text" style="">You won't be able to revert this!</div>
    <div class="swal-footer">
      <div class="swal-button-container">
        <button class="swal-button swal-button--cancel btn btn-danger" onclick="deleteCancel();">Cancel</button>
        <div class="swal-button__loader">
          <div></div>
          <div></div>
          <div></div>
        </div>
      </div>
      <div class="swal-button-container">
        <button class="swal-button swal-button--confirm btn btn-primary" onclick="deleteEvent();">OK</button>
        <div class="swal-button__loader">
          <div></div>
          <div></div>
          <div></div>
        </div>
      </div>
    </div>
  </div>
</div>

<div id="msgAppend"></div>
<!-- partial -->
<div class="container-fluid page-body-wrapper">
  <div class="main-panel">
    <div class="content-wrapper">
      <div class="page-header">
        <h3 class="page-title"> My Schedule </h3>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>admin">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">My Schedule</li>
          </ol>
        </nav>
      </div>

      <div class="row">
        <div class="col-md-12 grid-margin stretch-card">
          <div class="card">
            <div class="card-body">
              <div class="clearfix">
                <div class="row">
                  <!-- <h4 class="card-title float-left">Events</h4> -->
                  <div class="col-md-5">
                    <lable style="margin-right: 10px;">Team Members:</lable>
                    <select id="team_members" class="form-control" style="width: 50%;display: inline-block;color: black;border: 1px solid gray;">
                      <option value="-1">All</option>
                      <?php foreach ($team_members as $key => $value) { ?>
                        <option value="<?php echo $value->sq_u_id; ?>"><?php echo $value->sq_u_first_name; ?> <?php echo $value->sq_u_last_name; ?></option>
                      <?php  } ?>
                    </select>
                  </div>
                  <div class="col-md-5" style="margin-left: 170px !important;">
                    <button type="button" class="btn btn-success" id="add_event" style="float: right!important;"><i class="mdi mdi-plus"></i>Add Event</button>
                  </div>
                </div>
                <div id="visit-sale-chart-legend" class="rounded-legend legend-horizontal legend-top-right float-right"></div>
              </div>
              <div id="calendar" class="full-calendar"></div>
            </div>
          </div>
        </div>

      </div>
    </div>
    <!-- content-wrapper ends -->

    <div class="modal fade" id="createEventModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title" id="myModalLabel"><b>Add Calendar Event</b></h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          </div>
          <div class="modal-body" style="padding: 0px 0px;">
            <?php echo form_open(base_url("Admin/add_event"), array("class" => "form-horizontal")) ?>
            <div class="form-group">
              <label for="p-in" class="col-md-4 label-heading">Event Name</label>
              <div class="col-md-12 ui-front">
                <input type="text" class="form-control" name="title" value="" required>
              </div>
            </div>
            <div class="form-group">
              <label for="p-in" class="col-md-4 label-heading">Start Date</label>
              <div class="col-md-12">
                <input type="text" class="form-control" name="start" id="startTime" required>
              </div>
            </div>
            <div class="form-group">
              <label for="p-in" class="col-md-4 label-heading">End Date</label>
              <div class="col-md-12">
                <input type="text" class="form-control" name="end" id="endTime" required>
                <input type="hidden" class="form-control" name="select" id="select">
              </div>
            </div>
            <p id="when" style="margin-left: 20px;"></p>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default btn-sm" data-dismiss="modal">Close</button>
            <input type="submit" class="btn btn-success btn-sm" value="Add Event">
            <?php echo form_close() ?>
          </div>
        </div>
      </div>
    </div>

    <div class="modal fade" id="AddEventModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
      <div class="modal-dialog" role="document" style="max-width: 600px !important;">
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title" id="myModalLabel"><b>Add Calendar Event</b></h4>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          </div>
          <div class="modal-body" style="padding: 0px 0px;">
            <div class="form-group">
              <label for="p-in" class="col-md-4 label-heading">Event Type:</label>
              <div class="col-md-12 ui-front">
                <select class="form-control" id="eventType" name="eventType" style="border:1px solid #d0d0d0 !important;">
                  <option value="0">Choose</option>
                  <option value="Billing">Billing</option>
                  <option value="Send Invoice">Send Invoice</option>
                  <option value="Follow Up">Follow Up</option>
                  <option value="Appointment">Appointment</option>
                  <option value="Other">Other</option>
                </select>
              </div>
            </div>

            <div class="form-group">
              <div class="row event_calendar">
                <div class="col-md-6">
                  <label>Subject</label>
                  <input type="text" class="form-control" name="event_subject" id="event_subject" value="">
                </div>
                <div class="col-md-6">
                  <label>Event Name</label>
                  <input type="text" class="form-control" name="title" id="event_title" value="">
                </div>
              </div>
            </div>

            <div class="form-group">
              <div class="row event_calendar">
                <div class="col-md-6">
                  <label>Start Date & Time</label>
                  <input type="text" class="form-control datepicker_time" name="start" id="eventStartDateTime">
                </div>
                <div class="col-md-6">
                  <label>End Date & Time</label>
                  <input type="text" class="form-control datepicker_time" name="end" id="eventEndDateTime">
                  <input type="hidden" class="form-control" name="select" id="select">
                </div>
              </div>
            </div>

            <div class="form-group">
              <div class="row event_calendar">
                <div class="col-md-6">
                  <div class="form-check" style="margin-top: unset !important;">
                    <input type="checkbox" class="form-check-input" name="allDayEvent" id="allDayEvent" value="1" style="margin-left: unset !important;">
                    <label class="form-check-label">All Day Event</label>
                  </div>
                </div>
              </div>
            </div>

            <div class="form-group">
              <label for="p-in" class="col-md-4 label-heading">Clients</label>
              <div class="col-md-12">
                <select id="event_clients" class="form-control" style="border:1px solid #d0d0d0 !important;">
                  <option value="0">Choose</option>
                  <?php foreach ($clients as $clients_key => $clients_value) { ?>
                    <option value="<?php echo $clients_value->sq_client_id; ?>"><?php echo $clients_value->sq_first_name; ?> <?php echo $clients_value->sq_last_name; ?></option>
                  <?php  } ?>
                </select>
              </div>
            </div>

            <div class="form-group">
              <label for="p-in" class="col-md-4 label-heading">Location</label>
              <div class="col-md-12 ui-front">
                <input type="text" class="form-control" name="event_location" id="event_location" value="">
              </div>
            </div>

            <div class="form-group">
              <label for="p-in" class="col-md-4 label-heading">Remarks</label>
              <div class="col-md-12 ui-front">
                <input type="text" class="form-control" name="event_remarks" id="event_remarks" value="">
              </div>
            </div>

            <p id="when" style="margin-left: 20px;"></p>
          </div>

          <div class="modal-footer">
            <button type="button" class="btn btn-default btn-sm" data-dismiss="modal">Close</button>
            <input type="button" class="btn btn-success btn-sm" value="Add Event" onclick="add_new_calendar_event();">
          </div>
        </div>
      </div>
    </div>


    <script type="text/javascript">
      function openmydeletepopup(delID) {

        $('#hiddenClientId').val(delID);
        $('#deletePopup').css('display', '');
        $('#deletePopupModal').css('display', '');
        $('#loader').css('display', '');

      }

      function deleteCancel() {
        $('#deletePopup').css('display', 'none');
        $('#deletePopupModal').css('display', 'none');
      }

      function deleteEvent() {

        var id = $('#hiddenClientId').val();
        // Add Loader
        $.ajax({
          type: 'POST',
          url: '<?php echo base_url() . "Admin/delete_event"; ?>',
          data: {
            'id': id
          },
          success: function(response) {

            if (response == '1') {
              // Show Success message 
              $('#deletePopup').css('display', 'none');
              $('#deletePopupModal').css('display', 'none');

              var succesMsg = '<div id="pDsuccess" class="swal-overlay swal-overlay--show-modal" tabindex="-1"><div id="pDMsuccess" class="swal-modal" role="dialog" aria-modal="true"><div class="swal-icon swal-icon--success"><span class="swal-icon--success__line swal-icon--success__line--long"></span><span class="swal-icon--success__line swal-icon--success__line--tip"></span><div class="swal-icon--success__ring"></div><div class="swal-icon--success__hide-corners"></div></div><div class="swal-title" style="">Event Deleted!</div><div class="swal-text" style="">You have deleted one event successfully</div><div class="swal-footer"><div class="swal-button-container"><button class="swal-button swal-button--confirm btn btn-primary" onclick="closeSuccessModalee();">Close</button><div class="swal-button__loader"><div></div><div></div><div></div> </div></div></div></div></div>';

              $('#msgAppend').after(succesMsg);

            }

          }
        });
      }

      function closeSuccessModalee() {

        $('#pDsuccess').css('display', 'none');
        $('#pDMsuccess').css('display', 'none');
        //$('#items tr#row'+id).remove();
        location.reload();

      }

      function updateevent(msg) {

        var succesMsg = '<div id="pDsuccess" class="swal-overlay swal-overlay--show-modal" tabindex="-1"><div id="pDMsuccess" class="swal-modal" role="dialog" aria-modal="true"><div class="swal-icon swal-icon--success"><span class="swal-icon--success__line swal-icon--success__line--long"></span><span class="swal-icon--success__line swal-icon--success__line--tip"></span><div class="swal-icon--success__ring"></div><div class="swal-icon--success__hide-corners"></div></div><div class="swal-title" style="">Event Updated!</div><div class="swal-text" style="">' + msg + '</div><div class="swal-footer"><div class="swal-button-container"><button class="swal-button swal-button--confirm btn btn-primary" onclick="closeSuccessModalee();">Close</button><div class="swal-button__loader"><div></div><div></div><div></div> </div></div></div></div></div>';

        $('#msgAppend').after(succesMsg);

      }

      $('#add_event').on('click', function() {
        $('#AddEventModal').modal('show');
      });
    </script>