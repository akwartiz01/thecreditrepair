<?php
$client_status = $this->config->item('client_status');
$client_days_opt = $this->config->item('client_days_opt');

?>

<style>
  .switch {
    position: relative;
    display: inline-block;
    width: 55px;
    height: 25px;
  }

  .switch input {
    opacity: 0;
    width: 0;
    height: 0;
  }

  .slider {
    position: absolute;
    cursor: pointer;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: #ccc;
    transition: .4s;
  }

  .slider:before {
    position: absolute;
    content: "";
    height: 18px;
    width: 18px;
    left: 4px;
    bottom: 4px;
    background-color: white;
    transition: .4s;
  }

  input:checked+.slider {
    background-color: #4CAF50;
  }

  input:checked+.slider:before {
    transform: translateX(26px);
  }


  .slider.round {
    border-radius: 34px;
  }

  .slider.round:before {
    border-radius: 50%;
  }
</style>
<!-- partial -->
<div class="container-fluid page-body-wrapper">
  <div class="main-panel pnel">
    <div class="content-wrapper">
      <div class="page-header">
        <h3 class="page-title"> Edit Client </h3>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Edit Client</li>
          </ol>
        </nav>
      </div>
      <div class="card">
        <div class="card-body">
          <?php if ($this->session->flashdata('success')) { ?>
            <div id="pDsuccess" class="swal-overlay swal-overlay--show-modal" tabindex="-1">
              <div id="pDMsuccess" class="swal-modal" role="dialog" aria-modal="true">
                <div class="swal-icon swal-icon--success"><span class="swal-icon--success__line swal-icon--success__line--long"></span><span class="swal-icon--success__line swal-icon--success__line--tip"></span>
                  <div class="swal-icon--success__ring"></div>
                  <div class="swal-icon--success__hide-corners"></div>
                </div>
                <div class="swal-title">Client Updated!</div>
                <div class="swal-text" style=""><?php echo $this->session->flashdata('success'); ?></div>
                <div class="swal-footer">
                  <div class="swal-button-container"><button class="swal-button swal-button--confirm btn btn-primary" onclick="closeSuccessModal();">Continue</button>
                    <div class="swal-button__loader">
                      <div></div>
                      <div></div>
                      <div></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          <?php } ?>
          <form class="form-sample" method="POST">
            <input type="hidden" name="hiddenRowId" id="hiddenRowId" value="<?php echo isset($resultMyClients[0]->sq_client_id) ? $resultMyClients[0]->sq_client_id : ''; ?>">
            <div class="row">
              <div class="col-md-6">
                <div class="form-group row">
                  <label class="col-sm-3 col-form-label">First Name</label>
                  <div class="col-sm-9">
                    <input type="text" class="form-control" id="first_name" name="first_name" value="<?php echo isset($resultMyClients[0]->sq_first_name) ? $resultMyClients[0]->sq_first_name : ''; ?>" required="required">
                  </div>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group row">
                  <label class="col-sm-3 col-form-label">Middle name</label>
                  <div class="col-sm-9">
                    <input type="text" class="form-control" id="middle_name" name="middle_name" value="<?php echo isset($resultMyClients[0]->sq_middle_name) ? $resultMyClients[0]->sq_middle_name : ''; ?>">
                  </div>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6">
                <div class="form-group row">
                  <label class="col-sm-3 col-form-label">Last Name</label>
                  <div class="col-sm-9">
                    <input type="text" class="form-control" id="last_name" name="last_name" value="<?php echo isset($resultMyClients[0]->sq_last_name) ? $resultMyClients[0]->sq_last_name : ''; ?>" required="">
                  </div>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group row">
                  <label class="col-sm-3 col-form-label">Suffix</label>
                  <div class="col-sm-9">
                    <input type="text" class="form-control" id="suffix" name="suffix" value="<?php echo isset($resultMyClients[0]->sq_suffix) ? $resultMyClients[0]->sq_suffix : ''; ?>">
                  </div>
                </div>
              </div>

            </div>
            <div class="row">
              <div class="col-md-6">
                <div class="form-group row">
                  <label class="col-sm-3 col-form-label">Email</label>
                  <div class="col-sm-9">
                    <input type="text" class="form-control" id="email" name="email" value="<?php echo isset($resultMyClients[0]->sq_email) ? $resultMyClients[0]->sq_email : ''; ?>" required="">
                  </div>
                </div>
              </div>

              <div class="col-md-6">
                <div class="form-group row">
                  <label class="col-sm-4 col-form-label">Client has no email </label>
                  <div class="col-sm-4">
                    <div class="form-check">
                      <label class="form-check-label">
                        <input type="checkbox" class="form-check-input" name="noEmail" id="noEmail" value="1" onclick="hideEmail();"> <i class="input-helper"></i></label>
                    </div>
                  </div>

                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6">
                <div class="form-group row">
                  <label class="col-sm-3 col-form-label">SSN</label>
                  <div class="col-sm-9">
                    <input type="text" class="form-control" id="ssn" name="ssn" value="<?php echo isset($resultMyClients[0]->sq_ssn) ? $resultMyClients[0]->sq_ssn : ''; ?>">
                  </div>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group row">
                  <label class="col-sm-3 col-form-label">DOB</label>
                  <div class="col-sm-9">

                    <input type="text" class="form-control datepicker" id="dob" name="dob" value="<?php echo isset($resultMyClients[0]->sq_dob) && $resultMyClients[0]->sq_dob != '0000-00-00' ? date('m-d-Y', strtotime($resultMyClients[0]->sq_dob)) : '00-00-0000'; ?>">

                  </div>
                </div>
              </div>

            </div>
            <div class="row">
              <div class="col-md-6">
                <div class="form-group row">
                  <label class="col-sm-3 col-form-label">Phone (H)</label>
                  <div class="col-sm-9">
                    <input type="text" class="form-control" id="phone_home" name="phone_home" value="<?php echo isset($resultMyClients[0]->sq_phone_home) ? $resultMyClients[0]->sq_phone_home : ''; ?>">
                  </div>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group row">
                  <label class="col-sm-3 col-form-label">Phone (W)</label>
                  <div class="col-sm-9">
                    <input type="text" class="form-control" id="phone_work" name="phone_work" value="<?php echo isset($resultMyClients[0]->sq_phone_work) ? $resultMyClients[0]->sq_phone_work : ''; ?>">
                  </div>
                </div>
              </div>

            </div>
            <div class="row">
              <div class="col-md-6">
                <div class="form-group row">
                  <label class="col-sm-3 col-form-label">Phone (M)</label>
                  <div class="col-sm-9">
                    <input type="text" class="form-control" id="phone_mobile" name="phone_mobile" value="<?php echo isset($resultMyClients[0]->sq_phone_mobile) ? $resultMyClients[0]->sq_phone_mobile : ''; ?>" required>
                  </div>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group row">
                  <label class="col-sm-3 col-form-label">Alt Phone</label>
                  <div class="col-sm-9">
                    <input type="text" class="form-control" id="fax" name="fax" value="<?php echo isset($resultMyClients[0]->sq_fax) ? $resultMyClients[0]->sq_fax : ''; ?>" minlength="10">
                  </div>
                </div>
              </div>

            </div>

            <hr>
            <div class="row">
              <div class="col-md-6">
                <div class="form-group row">
                  <label class="col-sm-3 col-form-label">Status</label>
                  <div class="col-sm-9">
                    <!-- <input type="text" class="form-control" id="status" name="status" value="<?php echo isset($resultMyClients[0]->sq_status) ? $resultMyClients[0]->sq_status : ''; ?>" > -->
                    <select class="form-control" id="status" name="status">
                      <?php foreach ($client_status as $key => $value) { ?>
                        <option value="<?php echo $key; ?>" <?php if ($resultMyClients[0]->sq_status == $key) {
                                                              echo 'selected';
                                                            } ?>><?php echo $value; ?></option>
                      <?php } ?>
                    </select>
                  </div>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group row">
                  <label class="col-sm-3 col-form-label">Date of start</label>
                  <div class="col-sm-9">

                    <input type="text" class="form-control datepicker" id="date_of_start" name="date_of_start" value="<?php echo isset($resultMyClients[0]->sq_date_of_start) ? date('m-d-Y', strtotime($resultMyClients[0]->sq_date_of_start)) : ''; ?>">

                  </div>

                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-md-6">
                <div class="form-group row">
                  <label class="col-sm-3 col-form-label">Assigned to</label>
                  <div class="col-sm-9">


                    <select class="form-control" id="assigned" name="assigned">
                      <option value="">Select One</option>
                      <?php foreach ($get_allusers_name as $key => $value) { ?>
                        <option value="<?php echo $key; ?>" <?php if ($resultMyClients[0]->sq_assigned_to == $key) {
                                                              echo 'selected';
                                                            } ?>><?php echo $value; ?></option>
                      <?php } ?>
                    </select>

                  </div>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group row">
                  <label class="col-sm-3 col-form-label">Referred by</label>
                  <div class="col-sm-9">

                    <select class="form-control" id="referred" name="referred">
                      <option value="">Select One</option>
                      <?php foreach ($get_allaffiliate_name as $key => $value) { ?>
                        <option value="<?php echo $key; ?>" <?php if ($resultMyClients[0]->sq_referred_by == $key) {
                                                              echo 'selected';
                                                            } ?>><?php echo $value; ?></option>
                      <?php } ?>
                    </select>

                  </div>
                </div>
              </div>
            </div>
            <hr>
            <div class="row">

              <div class="col-md-6">
                <div class="form-group row">
                  <label class="col-sm-7 col-form-label">Portal Access (For Client Onboarding)</label>

                  <div class="col-sm-5" style="margin-top: 8px !important;">
                    <label class="switch">
                      <input type="checkbox" class="custom-control-input" id="portalAccess" name="portalAccess"
                        <?php echo ($resultMyClients[0]->sq_portal_access == 1) ? 'checked' : ''; ?>>
                      <span class="slider round"></span>
                    </label>
                  </div>
                </div>
              </div>

              <div class="col-md-6">
                <div class="form-group row">
                  <label class="col-sm-3 col-form-label">Client Days</label>
                  <div class="col-sm-9">
                    <select class="form-control" id="clientdays" name="client_days">
                      <?php foreach ($client_days_opt as $key => $value) { ?>
                        <option value="<?php echo $key; ?>" <?php if ($resultMyClients[0]->client_days == $key) {
                                                              echo 'selected';
                                                            } ?>><?php echo $value; ?></option>
                      <?php } ?>
                    </select>
                  </div>
                </div>
              </div>

            </div>
            <div class="row">
              <div class="col-md-6">
                <div class="form-group row">
                  <label class="col-sm-3 col-form-label">Mailing address</label>
                  <div class="col-sm-9">
                    <!-- <textarea class="form-control" id="mailing_address" name="mailing_address"><?php echo isset($resultMyClients[0]->sq_mailing_address) ? $resultMyClients[0]->sq_mailing_address : ''; ?></textarea> -->

                    <input class="form-control" id="mailing_address" name="mailing_address" value="<?php echo isset($resultMyClients[0]->sq_mailing_address) ? $resultMyClients[0]->sq_mailing_address : ''; ?>" placeholder="Enter your address">
                  </div>
                </div>
              </div>

            </div>

            <hr>
            <p class="card-description"> Address </p>
            <div class="row">
              <div class="col-md-6">
                <div class="form-group row">
                  <label class="col-sm-3 col-form-label">City</label>
                  <div class="col-sm-9">
                    <input type="text" class="form-control" id="city" name="city" value="<?php echo isset($resultMyClients[0]->sq_city) ? $resultMyClients[0]->sq_city : ''; ?>">

                  </div>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group row">
                  <label class="col-sm-3 col-form-label">State</label>
                  <div class="col-sm-9">
                    <input type="text" class="form-control" id="state" name="state" value="<?php echo isset($resultMyClients[0]->sq_state) ? $resultMyClients[0]->sq_state : ''; ?>">
                  </div>
                </div>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6">
                <div class="form-group row">
                  <label class="col-sm-3 col-form-label">Zip code</label>
                  <div class="col-sm-9">
                    <input type="text" class="form-control" id="zipcode" name="zipcode" value="<?php echo isset($resultMyClients[0]->sq_zipcode) ? $resultMyClients[0]->sq_zipcode : ''; ?>">
                  </div>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-group row">
                  <label class="col-sm-3 col-form-label">Country</label>
                  <div class="col-sm-9">
                    <input type="text" class="form-control" id="country" name="country" value="<?php echo isset($resultMyClients[0]->sq_country) ? $resultMyClients[0]->sq_country : ''; ?>">
                  </div>
                </div>
              </div>
            </div>
            <hr>
            <div class="col-md-12">
              <div class="form-group row">
                <div class="col-sm-1">
                  <div class="form-check">
                    <label class="form-check-label">
                      <input type="checkbox" class="form-check-input" name="previousMailing" id="previousMailing" onclick="displayPreviousMailing();"> <i class="input-helper"></i></label>
                  </div>
                </div>
                <label class="col-sm-9 col-form-label">Previous mailing address (only if at current mailing address for less than 2 years) </label>
              </div>

            </div>

            <div id="displayPreviousMailing" style="display: none;">
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group row">
                    <label class="col-sm-5 col-form-label">Previous Mailing address</label>
                    <div class="col-sm-7">
                      <textarea class="form-control" id="p_mailing_address" name="p_mailing_address"><?php echo isset($resultMyClients[0]->sq_p_mailing_address) ? $resultMyClients[0]->sq_p_mailing_address : ''; ?></textarea>
                    </div>
                  </div>
                </div>

              </div>
              <hr>
              <p class="card-description">Previous Address </p>
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group row">
                    <label class="col-sm-3 col-form-label">Previous City</label>
                    <div class="col-sm-9">
                      <input type="text" class="form-control" id="p_city" name="p_city" value="<?php echo isset($resultMyClients[0]->sq_p_city) ? $resultMyClients[0]->sq_p_city : ''; ?>  ">

                    </div>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group row">
                    <label class="col-sm-3 col-form-label">Previous State</label>
                    <div class="col-sm-9">
                      <input type="text" class="form-control" id="p_state" name="p_state" value="<?php echo isset($resultMyClients[0]->sq_p_state) ? $resultMyClients[0]->sq_p_state : ''; ?>  ">
                    </div>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group row">
                    <label class="col-sm-3 col-form-label">Previous Zip code</label>
                    <div class="col-sm-9">
                      <input type="text" class="form-control" id="p_zipcode" name="p_zipcode" value="<?php echo isset($resultMyClients[0]->sq_p_zipcode) ? $resultMyClients[0]->sq_p_zipcode : ''; ?>">
                    </div>
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group row">
                    <label class="col-sm-3 col-form-label">Previous Country</label>
                    <div class="col-sm-9">
                      <input type="text" class="form-control" id="p_country" name="p_country" value="<?php echo isset($resultMyClients[0]->sq_p_country) ? $resultMyClients[0]->sq_p_country : ''; ?>">
                    </div>
                  </div>
                </div>
              </div>

            </div>


            <div class="row">


              <div class="col-md-10">
                &nbsp;
              </div>
              <div class="col-md-2">
                <div class="form-group row">
                  <button type="submit" class="btn btn-gradient-primary btn-icon-text" id="btn_client" name="btn_client">
                    Update </button>
                </div>
              </div>


            </div>
          </form>

        </div>
      </div>
    </div>
    <!-- content-wrapper ends -->

    <script type="text/javascript">
      function displayPreviousMailing() {
        if ($('#previousMailing').is(':checked')) {
          $('#displayPreviousMailing').css('display', '');
        } else {
          $('#displayPreviousMailing').css('display', 'none');
        }

      }

      function hideEmail() {

        if ($('#noEmail').is(':checked')) {
          $("#email").prop('disabled', true);
          $('#email').removeAttr("required");
        } else {
          $("#email").prop('disabled', false);
          $('#email').attr("required", "required");
        }


      }
    </script>
    <script type="text/javascript">
      function closeSuccessModal() {
        $('#pDsuccess').css('display', 'none');
        $('#pDMsuccess').css('display', 'none');

      }
    </script>

    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDG1Jih1_t0oYWSky2LI9ZM399JMrjvh9o&libraries=places"></script>

    <script>
      function initializeAutocomplete() {
        var input = document.getElementById('mailing_address');
        var autocomplete = new google.maps.places.Autocomplete(input);


        autocomplete.setFields(['address_component', 'geometry']);

        autocomplete.addListener('place_changed', function() {
          var place = autocomplete.getPlace();

          fillAddressFields(place);
        });
      }

      function fillAddressFields(place) {
        var components = place.address_components;

        // console.log(components);

        var city = '',
          state = '',
          country = '',
          zipcode = '';

        for (var i = 0; i < components.length; i++) {
          var componentType = components[i].types[0];

          // console.log(componentType);

          switch (componentType) {
            case 'locality':
              city = components[i].long_name;
              break;
            case 'administrative_area_level_1':
              // state = components[i].short_name;
              state = components[i].long_name;
              break;
            case 'country':
              country = components[i].long_name;
              break;
            case 'postal_code':
              zipcode = components[i].long_name;
              break;
          }
        }

        document.getElementById('city').value = city;
        document.getElementById('state').value = state;
        document.getElementById('zipcode').value = zipcode;
        document.getElementById('country').value = country;
      }

      google.maps.event.addDomListener(window, 'load', initializeAutocomplete);
    </script>