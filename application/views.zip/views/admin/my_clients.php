<?php
$client_status = $this->config->item('client_status');

?>
<style type="text/css">
  .modal .modal-dialog .modal-content .modal-body {
    padding: 0px 26px 0px 26px;
  }

  /**** NEW CODE ****/
  a.s_icon {
    font-size: 20px;
  }

  select.custom-select-sm {
    color: black;
    border: 1px solid #d0d0d0;
  }

  .card .card-body {
    padding: 1.25rem !important;
  }

  /* @media (min-width: 1200px) {
    .container-scroller .content-wrapper {
      max-width: 1550px !important;
    }
  }

  @media (min-width: 992px) {
    .container-scroller .content-wrapper {
      max-width: 1350px !important;
    }
  } */

  /**** END NEW CODE ****/
</style>
<div id="deletePopup" class="swal-overlay swal-overlay--show-modal" tabindex="-1" style="display: none;">
  <div id="deletePopupModal" class="swal-modal" role="dialog" aria-modal="true" style="display: none;">
    <input type="hidden" name="hiddenClientId" id="hiddenClientId" value="">
    <div class="swal-icon swal-icon--warning">
      <span class="swal-icon--warning__body">
        <span class="swal-icon--warning__dot"></span>
      </span>
    </div>
    <div class="swal-title" style="">Are you sure?</div>
    <div class="swal-text" style="">You won't be able to revert this!</div>
    <div class="swal-footer">
      <div class="swal-button-container">
        <button class="swal-button swal-button--cancel btn btn-danger" onclick="deleteCancel();">Cancel</button>
        <div class="swal-button__loader">
          <div></div>
          <div></div>
          <div></div>
        </div>
      </div>
      <div class="swal-button-container">
        <button class="swal-button swal-button--confirm btn btn-primary" onclick="deleteClient();">OK</button>
        <div class="swal-button__loader">
          <div></div>
          <div></div>
          <div></div>
        </div>
      </div>
    </div>
  </div>
</div>

<div id="msgAppend">
</div>

<?php if ($this->session->flashdata('success')) { ?>
  <div id="pDsuccess" class="swal-overlay swal-overlay--show-modal" tabindex="-1">
    <div id="pDMsuccess" class="swal-modal" role="dialog" aria-modal="true">
      <div class="swal-icon swal-icon--success"><span class="swal-icon--success__line swal-icon--success__line--long"></span><span class="swal-icon--success__line swal-icon--success__line--tip"></span>
        <div class="swal-icon--success__ring"></div>
        <div class="swal-icon--success__hide-corners"></div>
      </div>
      <div class="swal-title" style="">Email Notification!</div>
      <div class="swal-text" style=""><?php echo $this->session->flashdata('success'); ?></div>
      <div class="swal-footer">
        <div class="swal-button-container"><button class="swal-button swal-button--confirm btn btn-primary" onclick="closeSuccessModal();">Continue</button>
          <div class="swal-button__loader">
            <div></div>
            <div></div>
            <div></div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php } ?>

<!-- partial -->
<div class="container-fluid page-body-wrapper">
  <div class="main-panel">
    <div class="content-wrapper">
      <div class="page-header">
        <h3 class="page-title"> My Clients </h3>
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>admin">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">My Clients</li>
          </ol>
        </nav>
      </div>
      <div class="card">
        <div class="card-body">
          <div class="row">
            <div class="col-12 mb-4">
              <a href="<?php echo base_url(); ?>add-client"><button type="button" class="btn btn-success btn-sm float-right"><i class="mdi mdi-account"></i> Add Client</button></a>
            </div>
          </div>

          <div class="row">
            <div class="col-12 table-responsive">
              <table class="table my_clients_datatable">
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>E-mail</th>
                    <th>Phone No</th>
                    <th>Assigned To</th>
                    <th>Referred By</th>
                    <th>Added</th>
                    <th>Start Date</th>
                    <th>Last Login</th>
                    <th>Onboarding Stage</th>
                    <th>Company</th>
                    <th>Status</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!---------- email send ------------->
    <div class="modal fade" id="emailsend" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <form method="post" action="<?php echo base_url(); ?>Admin/sendemailNotification">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel"><b>Email Notification</b></h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <input type="hidden" name="clientID" id="clientID" value="">

              <div class="row mb-2">
                <div class="col-12">
                  <label>Subject:</label>
                  <input type="text" name="subject" class="form-control" required="required" autocomplete="off">
                </div>
              </div>

              <div class="row mb-2">
                <div class="col-12">
                  <label>Message:</label>
                  <textarea class="form-control" name="msg" rows="5"></textarea>
                </div>
              </div>

            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Close</button>
              <button type="submit" name="send" class="btn btn-success btn-sm">Send</button>
            </div>
          </form>
        </div>
      </div>
    </div>
    <!---------- email send ------------->
    <!-- content-wrapper ends -->

    <script type="text/javascript">
      function sendEmailPopUp(that, clientID) {

        $('#emailsend input#clientID').val(clientID);
        $('#emailsend').modal('show');

      }

      function deleteClientPopUp(that, id) {

        $('#hiddenClientId').val(id);
        $('#deletePopup').css('display', '');
        $('#deletePopupModal').css('display', '');
        $('#loader').css('display', '');

      }

      function deleteCancel() {
        $('#deletePopup').css('display', 'none');
        $('#deletePopupModal').css('display', 'none');
      }

      function closeSuccessModal() {
        $('#pDsuccess').css('display', 'none');
        $('#pDMsuccess').css('display', 'none');
        location.reload();

      }

      function deleteClient() {

        var id = $('#hiddenClientId').val();
        // Add Loader
        $.ajax({
          type: 'POST',
          url: '<?php echo base_url() . "Admin/deleteClient"; ?>',
          data: {
            'id': id
          },
          success: function(response) {

            var data = JSON.parse(response);

            if ($.trim(data) == 'deleted') {
              // Show Success message 
              $('#deletePopup').css('display', 'none');
              $('#deletePopupModal').css('display', 'none');

              var succesMsg = '<div id="pDsuccess" class="swal-overlay swal-overlay--show-modal" tabindex="-1"><div id="pDMsuccess" class="swal-modal" role="dialog" aria-modal="true"><div class="swal-icon swal-icon--success"><span class="swal-icon--success__line swal-icon--success__line--long"></span><span class="swal-icon--success__line swal-icon--success__line--tip"></span><div class="swal-icon--success__ring"></div><div class="swal-icon--success__hide-corners"></div></div><div class="swal-title" style="">Client Deleted!</div><div class="swal-text" style="">You have deleted the client successfully</div><div class="swal-footer"><div class="swal-button-container"><button class="swal-button swal-button--confirm btn btn-primary" onclick="closeSuccessModal();">Continue</button><div class="swal-button__loader"><div></div><div></div><div></div> </div></div></div></div></div>';

              $('#msgAppend').after(succesMsg);

            }

          }
        });
      }

    </script>