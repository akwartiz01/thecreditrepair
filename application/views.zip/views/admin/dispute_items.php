<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet" />
<!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"> -->

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
    .status-check {
        color: green;
        font-size: 1.2rem;
    }

    .dropdown-toggle::after {
        display: none;
    }

    .table td,
    .table th {
        vertical-align: middle;
    }

    .credit-header {
        text-align: center;
        font-weight: bold;
    }

    .btn-new-item {
        float: right;
        margin-bottom: 10px;
    }

    .navigation_mini .btn {
        padding: 10px 38px !important;
    }

    .text-success {
        color: #3972fc !important;
    }
</style>

<div class="container-fluid page-body-wrapper">
    <div class="main-panel pnel">
        <div class="content-wrapper">

            <div class="row">
                <div class="col-md-12 navigation_mini" style="display: flex; flex-wrap: wrap; gap: 10px; justify-content:center;">

                    <a type="button" href="<?php echo base_url(); ?>dashboard/<?php echo get_encoded_id($client[0]->sq_client_id); ?>" class="btn btn-icons btn-light text-success mb-2 navigation-buttons"><i class="mdi mdi-account-circle"></i> Dashboard</a>

                    <a type="button" href="<?php echo base_url(); ?>import_audit/<?php echo get_encoded_id($client[0]->sq_client_id); ?>" class="btn btn-icons btn-light text-success mb-2 navigation-buttons"><i class="mdi mdi-file-document"></i> Import/Audit</a>

                    <a type="button" href="<?php echo base_url(); ?>import_audit/<?php echo get_encoded_id($client[0]->sq_client_id); ?>" class="btn btn-icons btn-light text-success mb-2 navigation-buttons"><i class="mdi mdi-file-powerpoint"></i> Tag Pending Report</a>

                    <a type="button" href="<?php echo base_url(); ?>send_letter/<?php echo get_encoded_id($client[0]->sq_client_id); ?>" class="btn btn-icons btn-light text-success mb-2 navigation-buttons"><i class="mdi mdi-email"></i> Send Letters</a>

                    <a type="button" href="<?php echo base_url('letters-status/' . get_encoded_id($client[0]->sq_client_id)); ?>" class="btn btn-icons btn-light text-success mb-2 navigation-buttons"><i class="mdi mdi-email"></i> Letters & Status
                    </a>

                    <a type="button" href="<?php echo base_url('dispute_items/' . get_encoded_id($client[0]->sq_client_id)); ?>" class="btn btn-icons btn-light text-success mb-2 navigation-buttons"><i class="mdi mdi-note-plus"></i> Dispute Items</a>

                    <a type="button" href="<?php echo base_url('messages/send/' . get_encoded_id($client[0]->sq_client_id)); ?>" class="btn btn-icons btn-light text-success mb-2 navigation-buttons"><i class="mdi mdi-comment"></i> Messages
                    </a>

                </div>
            </div>


            <button class="btn btn-success btn-new-item"><i class="fas fa-plus"></i> Add New Item</button>

            <table class="table table-bordered">
                <thead class="table-light">
                    <tr>
                        <th>Creditor/Furnisher</th>
                        <th>Account #</th>
                        <th>Dispute Items</th>
                        <th class="credit-header">Equifax</th>
                        <th class="credit-header">Experian</th>
                        <th class="credit-header">TransUnion</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>WFBNB CARD</td>
                        <td>
                            Equifax: <br>
                            Experian: <br>
                            Transunion:
                        </td>
                        <td>-</td>
                        <td colspan="3" class="text-center text-muted">-</td>
                        <td class="text-end">
                            <div class="dropdown">
                                <button class="btn btn-link text-dark dropdown-toggle" data-bs-toggle="dropdown">
                                    <i class="fas fa-ellipsis-v"></i>
                                </button>
                                <ul class="dropdown-menu">
                                    <li><a class="dropdown-item" href="#">Edit</a></li>
                                    <li><a class="dropdown-item" href="#">Delete</a></li>
                                </ul>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>ROUNDPOINT MORTGAGE</td>
                        <td>
                            Equifax: 596201123456<br>
                            Experian: 596201123456<br>
                            Transunion: 596201123456
                        </td>
                        <td>-</td>
                        <td class="text-center"><i class="fas fa-check status-check"></i><br>
                            <select class="form-select">
                                <option selected>Select</option>
                                <option>Unspecified</option>
                                <option>Positive</option>
                                <option>Deleted</option>
                                <option>Repaired</option>
                                <option>Updated</option>
                                <option>In Dispute</option>
                                <option>Verified</option>
                                <option>Negative</option>
                            </select>
                        </td>
                        <td class="text-center"><i class="fas fa-check status-check"></i><br>
                            <select class="form-select">
                                <option selected>Select</option>
                                <option>Unspecified</option>
                                <option>Positive</option>
                                <option>Deleted</option>
                                <option>Repaired</option>
                                <option>Updated</option>
                                <option>In Dispute</option>
                                <option>Verified</option>
                                <option>Negative</option>
                            </select>
                        </td>
                        <td class="text-center"><i class="fas fa-check status-check"></i><br>
                            <select class="form-select">
                                <option selected>Select</option>
                                <option>Unspecified</option>
                                <option>Positive</option>
                                <option>Deleted</option>
                                <option>Repaired</option>
                                <option>Updated</option>
                                <option>In Dispute</option>
                                <option>Verified</option>
                                <option>Negative</option>
                            </select>
                        </td>
                        <td class="text-end">
                            <div class="dropdown">
                                <button class="btn btn-link text-dark dropdown-toggle" data-bs-toggle="dropdown">
                                    <i class="fas fa-ellipsis-v"></i>
                                </button>
                                <ul class="dropdown-menu">
                                    <li><a class="dropdown-item" href="#">Edit</a></li>
                                    <li><a class="dropdown-item" href="#">Delete</a></li>
                                </ul>
                            </div>
                        </td>
                    </tr>
                    <!-- Repeat similar structure for other rows -->
                </tbody>
            </table>

        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="editDisputeModal" tabindex="-1" aria-labelledby="editDisputeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editDisputeModalLabel">Edit dispute item</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form>
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <label class="form-label">Date:</label>
                            <input type="text" class="form-control" value="12/16/2024" readonly>
                        </div>
                        <div class="col-md-8">
                            <label class="form-label">Creditor/Furnisher:</label>
                            <select class="form-select">
                                <option selected>ROUNDPOINT MORTGAGE</option>
                            </select>
                        </div>
                    </div>

                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Reason:</label>
                            <select class="form-select">
                                <option selected>-</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Instruction:</label>
                            <textarea class="form-control" rows="2"></textarea>
                        </div>
                    </div>

                    <div class="row">
                        <!-- Equifax -->
                        <div class="col-md-4 form-section">
                            <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" checked>
                                <label class="form-check-label">
                                    <img src="https://upload.wikimedia.org/wikipedia/commons/4/4f/Equifax_Logo_2021.svg" class="credit-bureau-logo" alt="Equifax">
                                </label>
                            </div>
                            <div class="mb-2">
                                <label class="form-label">Status:</label>
                                <select class="form-select">
                                    <option selected>Positive</option>
                                </select>
                            </div>
                            <div class="mb-2">
                                <label class="form-label">Account Name:</label>
                                <input type="text" class="form-control" value="ROUNDPOINT MO">
                            </div>
                            <div class="mb-2">
                                <label class="form-label">Account Number:</label>
                                <input type="text" class="form-control" value="596201************">
                            </div>
                            <div>
                                <label class="form-label">Date Reported:</label>
                                <input type="text" class="form-control" value="12/16/2024">
                            </div>
                        </div>

                        <!-- Experian -->
                        <div class="col-md-4 form-section">
                            <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" checked>
                                <label class="form-check-label">
                                    <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/fb/Experian_logo.svg/2560px-Experian_logo.svg.png" class="credit-bureau-logo" alt="Experian">
                                </label>
                            </div>
                            <div class="mb-2">
                                <label class="form-label">Status:</label>
                                <select class="form-select">
                                    <option selected>Positive</option>
                                </select>
                            </div>
                            <div class="mb-2">
                                <label class="form-label">Account Name:</label>
                                <input type="text" class="form-control" value="ROUNDPOINT MO">
                            </div>
                            <div class="mb-2">
                                <label class="form-label">Account Number:</label>
                                <input type="text" class="form-control" value="596201************">
                            </div>
                            <div>
                                <label class="form-label">Date Reported:</label>
                                <input type="text" class="form-control" value="12/16/2024">
                            </div>
                        </div>

                        <!-- TransUnion -->
                        <div class="col-md-4 form-section">
                            <div class="form-check mb-2">
                                <input class="form-check-input" type="checkbox" checked>
                                <label class="form-check-label">
                                    <img src="https://upload.wikimedia.org/wikipedia/commons/0/04/TransUnion_logo_2016.svg" class="credit-bureau-logo" alt="TransUnion">
                                </label>
                            </div>
                            <div class="mb-2">
                                <label class="form-label">Status:</label>
                                <select class="form-select">
                                    <option selected>Positive</option>
                                </select>
                            </div>
                            <div class="mb-2">
                                <label class="form-label">Account Name:</label>
                                <input type="text" class="form-control" value="ROUNDPOINT MO">
                            </div>
                            <div class="mb-2">
                                <label class="form-label">Account Number:</label>
                                <input type="text" class="form-control" value="596201************">
                            </div>
                            <div>
                                <label class="form-label">Date Reported:</label>
                                <input type="text" class="form-control" value="12/16/2024">
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-link" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-success">Save</button>
            </div>
        </div>
    </div>
</div>


<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>