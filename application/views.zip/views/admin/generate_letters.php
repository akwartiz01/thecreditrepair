<?php
$us_states = $this->config->item('us_states');

$name = trim(($client[0]->sq_first_name ?? '') . ' ' . ($client[0]->sq_last_name ?? ''));

?>
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet" />

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">


<style>
  .mce-notification {
    display: none;
  }

  .form_error {
    color: red;
    font-weight: bold;
  }

  legend {
    padding: 5px 20px;
    font-size: 20px;
    font-weight: bold;
  }

  .placeholder_section .col-md-6 {
    font-size: 13px;
    line-height: 20px;
  }

  #loader {
    display: none;
    position: fixed;
    z-index: 9999;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
  }

  .spinner {
    border: 16px solid #f3f3f3;
    border-top: 16px solid #3498db;
    border-radius: 50%;
    width: 120px;
    height: 120px;
    animation: spin 2s linear infinite;
  }

  @keyframes spin {
    0% {
      transform: rotate(0deg);
    }

    100% {
      transform: rotate(360deg);
    }
  }

  /* errors css s  */
  .is-invalid {
    border-color: #dc3545;
  }

  .invalid-feedback {
    color: #dc3545;
    display: block;
  }

  /* errors css e */


  /* Swal css s */

  .swal2-modal .swal2-icon,
  .swal2-modal .swal2-success-ring {
    margin-top: 0 !important;
    margin-bottom: 0px !important;
  }

  /* Swal css e */

  .form-control {
    color: black !important;
  }

  input[type="tel"]::placeholder {
    color: black;
  }

  input[type="text"]::placeholder {
    color: black;
  }

  .form-sample .form-group.row {
    margin-bottom: 1.5rem !important;
  }

  select.is-invalid {
    outline: 1px solid #dc3545 !important;
  }

  .cloudmailAddress {
    font-weight: 700 !important;
    font-size: 15px !important;
  }

  #envelope_address {
    border: 1px solid #d0d0d0 !important;
    padding: 15px 0px 15px 0px !important;
    margin: auto !important;
    border-radius: 10px !important;
  }

  .envelopeAddress {
    display: none;
  }
</style>

<style>
  body {
    font-family: Arial, sans-serif;
    background-color: #f9f9f9;
    margin: 20px;
    color: #343a40;
  }

  h2 {
    color: #343a40;
  }

  #dispute-container {
    background-color: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    margin-bottom: 20px;
  }

  .step-title {
    font-weight: bold;
    margin-bottom: 10px;
  }

  .radio-group {
    margin-bottom: 20px;
  }

  .radio-group label {
    display: block;
    margin-bottom: 5px;
  }

  .link {
    color: #1a73e8;
    text-decoration: none;
    font-size: 14px;
  }

  .link:hover {
    text-decoration: underline;
  }

  .btn {
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 14px;
  }

  #btn-saved-dispute {
    background-color: #28a745;
    color: white;
    margin-right: 10px;
  }

  #btn-new-dispute {
    background-color: #e0e0e0;
    color: #555;
  }

  #btn-generate-unique {
    background-color: #0d6efd;
    color: white;
  }

  #dispute-table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 10px;
  }

  #dispute-table th,
  #dispute-table td {
    padding: 12px;
    border-bottom: 1px solid #ccc;
    text-align: left;
  }

  #dispute-table th {
    background-color: #f1f1f1;
  }

  .no-data {
    text-align: center;
    padding: 20px;
    color: #999;
  }

  #btn-container {
    margin-top: 20px;
    display: flex;
    justify-content: flex-end;
  }

  #btn-generate-library {
    background-color: #e0e0e0;
    color: #555;
    margin-right: 10px;
  }

  #link-generate-letter {
    float: right !important;
  }

  .radio-group label {
    margin-bottom: 20px !important;
  }

  .step-title {
    margin-bottom: 20px !important;
  }

  input[type="radio"],
  input[type="checkbox"] {

    margin-right: 10px !important;
  }

  .navigation_mini .btn {
    padding: 10px 38px !important;
  }

  .text-success {
    color: #3972fc !important;
  }
</style>

<style>
  /* .modal-header {
    background-color: #f8f9fa;
    border-bottom: 1px solid #dee2e6;
  }

  .modal-footer {
    border-top: 1px solid #dee2e6;
  }

  .modal-content {
    border-radius: 8px;
  }

  .credit-bureau-logo {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 8px;
  } */
</style>


<div id="loader">
  <img src="<?php echo base_url('assets/loading-gif.gif'); ?>" style="height: 50px;" alt="Loading..." class="loader-image">
</div>

<div class="container-fluid page-body-wrapper">
  <div class="main-panel pnel">
    <div class="content-wrapper">

      <div class="row">
        <div class="col-md-12 navigation_mini" style="display: flex; flex-wrap: wrap; gap: 10px; justify-content:center;">

          <a type="button" href="<?php echo base_url(); ?>dashboard/<?php echo get_encoded_id($client[0]->sq_client_id); ?>" class="btn btn-icons btn-light text-success mb-2 navigation-buttons"><i class="mdi mdi-account-circle"></i> Dashboard</a>

          <a type="button" href="<?php echo base_url(); ?>import_audit/<?php echo get_encoded_id($client[0]->sq_client_id); ?>" class="btn btn-icons btn-light text-success mb-2 navigation-buttons"><i class="mdi mdi-file-document"></i> Import/Audit</a>

          <a type="button" href="<?php echo base_url(); ?>import_audit/<?php echo get_encoded_id($client[0]->sq_client_id); ?>" class="btn btn-icons btn-light text-success mb-2 navigation-buttons"><i class="mdi mdi-file-powerpoint"></i> Tag Pending Report</a>



          <a type="button" href="<?php echo base_url(); ?>send_letter/<?php echo get_encoded_id($client[0]->sq_client_id); ?>" class="btn btn-icons btn-light text-success mb-2 navigation-buttons"><i class="mdi mdi-email"></i> Send Letters</a>

          <a type="button" href="<?php echo base_url('letters-status/' . get_encoded_id($client[0]->sq_client_id)); ?>" class="btn btn-icons btn-light text-success mb-2 navigation-buttons"><i class="mdi mdi-email"></i> Letters & Status
          </a>

          <a type="button" href="<?php echo base_url('dispute_items/' . get_encoded_id($client[0]->sq_client_id)); ?>" class="btn btn-icons btn-light text-success mb-2 navigation-buttons"><i class="mdi mdi-note-plus"></i> Dispute Items</a>

          <a type="button" href="<?php echo base_url('messages/send/' . get_encoded_id($client[0]->sq_client_id)); ?>" class="btn btn-icons btn-light text-success mb-2 navigation-buttons"><i class="mdi mdi-comment"></i> Messages
          </a>

        </div>
      </div>

      <div class="card">
        <div class="card-body">

          <h2>Dispute Wizard (<?php echo $name; ?>)</h2>

          <p>
            Build a dispute letter by either selecting saved dispute items or adding new items manually.
            <!-- <a href="#" class="link" id="link-quick-video">Quick Video</a> -->
          </p>

          <div id="dispute-container">
            <div class="step-title">Step 1: Choose Letter Type</div>
            <div class="radio-group" id="radio-group-letter-type">
              <label>
                <input type="radio" name="letter_type" id="basic_dispute">Round 1 <em>Basic Dispute</em>
              </label>

            </div>

          </div>

          <div id="dispute-container">
            <div class="step-title">Step 2: Add Dispute Items</div>
            <p>
              To ensure your disputes are taken seriously and not rejected by the credit bureaus, we advise limiting the number of dispute items to 5 per month per bureau (unless it involves identity theft with a police report).
            </p>
            <button class="btn" id="btn-saved-dispute">+ Saved Dispute Item</button>
            <button type="button" class="btn" id="btn-new-dispute">+ New Dispute Item</button>


            <table class="table table-bordered shadow-sm mt-3">

              <thead class="thead-light">
                <tr>
                  <th>#</th>
                  <th>Creditor/Furnisher</th>
                  <th>Account #</th>
                  <th>Dispute Items</th>
                  <th><img src="<?= base_url('downloads/simple_audit_images/equifax.png'); ?>" style="height: 30px !important; width: auto !important;"></th>
                  <th><img src="<?= base_url('downloads/simple_audit_images/experian.png'); ?>" style="height: 30px !important; width: auto !important;"></th>
                  <th><img src="<?= base_url('downloads/simple_audit_images/trans_union.png'); ?>" style="height: 30px !important; width: auto !important;"></th>
                  <th></th>
                </tr>
              </thead>

              <tbody>
                <?php
                $index = 0;
                if (!empty($items)): ?>
                  <?php foreach ($items as $item):
                    $index++;
                  ?>
                    <tr>
                      <td><?= $index; ?></td>
                      <td></td>
                      <td>
                        <?php if ($item->equifax_account): ?>
                          <strong>Equifax:</strong> <?= htmlspecialchars($item->equifax_account) ?><br>
                        <?php endif; ?>
                        <?php if ($item->experian_account): ?>
                          <strong>Experian:</strong> <?= htmlspecialchars($item->experian_account) ?><br>
                        <?php endif; ?>
                        <?php if ($item->transunion_account): ?>
                          <strong>Transunion:</strong> <?= htmlspecialchars($item->transunion_account) ?>
                        <?php endif; ?>
                      </td>
                      <td><?= htmlspecialchars($item->dispute_reason) ?></td>
                      <td>
                        <?php if ($item->equifax): ?>
                          <img src="<?= base_url('assets/negative.png'); ?>" height="20"><br>
                          <span class="text-danger small">Negative</span>
                        <?php endif; ?>
                      </td>
                      <td>
                        <?php if ($item->experian): ?>
                          <img src="<?= base_url('assets/negative.png'); ?>" height="20"><br>
                          <span class="text-danger small">Negative</span>
                        <?php endif; ?>
                      </td>
                      <td>
                        <?php if ($item->transunion): ?>
                          <img src="<?= base_url('assets/negative.png'); ?>" height="20"><br>
                          <span class="text-danger small">Negative</span>
                        <?php endif; ?>
                      </td>
                      <td>
                        <a href="#" class="text-danger delete-dispute" data-id="<?= $item->id ?>">
                          <i class="fa fa-trash fa-lg"></i>
                        </a>
                      </td>
                    </tr>
                  <?php endforeach; ?>
                <?php else: ?>
                  <tr>
                    <td colspan="7" class="text-center text-muted">No dispute items added yet.</td>
                  </tr>
                <?php endif; ?>
              </tbody>
            </table>


            <div id="btn-container">
              <button class="btn" id="btn-generate-library">Generate Library Letter</button>
              <button class="btn" id="btn-generate-unique">Generate Unique AI Letter</button>
            </div>
          </div>

        </div>
      </div>
    </div>
  </div>
</div>

<!-- Bootstrap Modal -->

<!-- Modal -->
<div class="modal fade" id="disputeModal" tabindex="-1" aria-labelledby="modalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalLabel">Add New Dispute Item</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="row">
          <div class="col-6">
            <div class="col">

              <label>Select Credit Bureaus <span class="text-danger">*</span></label>
              <div class="form-check">
                <input type="checkbox" class="form-check-input" id="equifax" value="1" />
                <label class="form-check-label credit-bureau-logo" for="equifax">
                  <img src="<?php echo base_url('downloads/simple_audit_images/equifax.png'); ?>" style="height: 30px !important;" alt="Equifax">
                </label>
              </div>

              <div class="form-check">
                <input type="checkbox" class="form-check-input" id="experian" value="1" />
                <label class="form-check-label credit-bureau-logo" for="experian">
                  <img src="<?php echo base_url('downloads/simple_audit_images/experian.png'); ?>" style="height: 30px !important;" alt="Experian">
                </label>
              </div>

              <div class="form-check">
                <input type="checkbox" class="form-check-input" id="transunion" value="1" />
                <label class="form-check-label credit-bureau-logo" for="transunion">
                  <img src="<?php echo base_url('downloads/simple_audit_images/trans_union.png'); ?>" style="height: 30px !important;" alt="TransUnion">
                </label>
              </div>

              <div class="form-group" style="margin-top: 30px !important;">
                <label>Account Number (Optional)</label>
                <div>
                  <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="accountNumber" id="sameForAll" />
                    <label class="form-check-label" for="sameForAll">Same for all bureaus</label>
                  </div>
                  <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="accountNumber" id="differentForEach" />
                    <label class="form-check-label" for="differentForEach">Different for each bureau</label>
                  </div>
                </div>

              </div>


            </div>
          </div>

          <div class="col-6">

            <div class="col">
              <div class="form-group mt-3">
                <label>Creditor/Furnisher</label>
                <select class="form-control" id="creditor_furnisher">
                  <option value="0" selected>Search a Creditor/Furnisher</option>
                </select>

              </div>


              <div class="form-group">
                <label>Reason <span class="text-danger">*</span></label>
                <select class="form-control" id="dispute_reason">
                  <option value="0" selected>Select a reason for your dispute</option>
                  <option value="">Sample Reason</option>
                  <option value="">The following personal information is incorrect</option>
                  <option value="">The following account is not mine</option>
                  <option value="">The status is incorrect for the following account</option>
                  <option value="">The status is incorrect for the following account</option>
                  <option value="">The following information is outdated. I would like it removed from my credit history report</option>
                  <option value="">The following inquiry is more than two years old and I would like it removed</option>
                  <option value="">The inquiry was not authorized</option>
                  <option value="">The following accounts were closed by me and should state that</option>
                  <option value="">The following account was a Bankruptcy/Charge-off. Balance should be $0</option>
                  <option value="">Mistaken Identity</option>
                  <option value="">Identity Theft</option>
                  <option value="">Other information I would like changed</option>
                  <option value="">This is a duplicate account</option>
                  <option value="">The wrong amount is being reported</option>
                  <option value="">This is the wrong creditor for this item</option>
                  <option value="">Validate Account</option>
                  <option value="">-</option>
                  <option value="">Late Payments</option>
                  <option value="">Charged Off</option>
                  <option value="">Account Closed</option>
                  <option value="">15 USC 1666 USC 1666B 12 CFR 1026.13 - Billing Error - Late Payments</option>
                </select>

              </div>

              <div class="form-group">
                <label>Instruction</label>
                <select class="form-control" id="dispute_instructions">
                  <option value="0" selected>Choose instructions</option>
                </select>

              </div>

            </div>
          </div>

          <div class="col-6">

            <div class="form-check" style="display: none;">
              <input type="text" class="form-control mt-2" id="account_number_all" placeholder="Enter account number">
            </div>

            <div class="form-check" style="display: none;">
              <label>Equifax</label>
              <input type="text" name="equifax_account" id="equifax_account" class="form-control">
            </div>

            <div class="form-check" style="display: none;">
              <label>Experian</label>
              <input type="text" name="experian_account" id="experian_account" class="form-control">
            </div>

            <div class="form-check" style="display: none;">
              <label>Transunion</label>
              <input type="text" name="transunion_account" id="transunion_account" class="form-control">
            </div>

          </div>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
          <button type="button" class="btn btn-success">Save</button>
        </div>
      </div>
    </div>
  </div>
</div>



<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>

<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<!-- <script>
  $(document).ready(function() {
    function toggleAccountFields() {
      const sameForAll = $('#sameForAll').is(':checked');
      const differentForEach = $('#differentForEach').is(':checked');

      // If same for all, show only one input
      if (sameForAll) {
        $('#account_number_all').closest('.form-check').show();

        if ($('#equifax').is(':checked')) $('#equifax_account').closest('.form-check').hide();
        if ($('#experian').is(':checked')) $('#experian_account').closest('.form-check').hide();
        if ($('#transunion').is(':checked')) $('#transunion_account').closest('.form-check').hide();
      }

      // If different for each, show individual ones
      if (differentForEach) {
        $('#account_number_all').val('').closest('.form-check').hide();

        if ($('#equifax').is(':checked')) $('#equifax_account').closest('.form-check').show();
        if ($('#experian').is(':checked')) $('#experian_account').closest('.form-check').show();
        if ($('#transunion').is(':checked')) $('#transunion_account').closest('.form-check').show();
      }
    }

    // When radio buttons change
    $('#sameForAll, #differentForEach').change(function() {
      toggleAccountFields();
    });

    // When checkboxes change
    $('#equifax, #experian, #transunion').change(function() {
      toggleAccountFields();
    });

    // Save button click
    $('.btn-success').click(function() {
      const data = {
        bureaus: {
          equifax: $('#equifax').is(':checked'),
          experian: $('#experian').is(':checked'),
          transunion: $('#transunion').is(':checked')
        },
        account_mode: $('input[name="accountNumber"]:checked').attr('id'),
        account_number_all: $('#account_number_all').val(),
        equifax_account: $('#equifax_account').val(),
        experian_account: $('#experian_account').val(),
        transunion_account: $('#transunion_account').val(),
        creditor_furnisher: $('#creditor_furnisher').val(),
        dispute_reason: $('#dispute_reason').val(),
        dispute_instruction: $('#dispute_instructions').val()
      };

      $.ajax({
        url: '<?= base_url("Admin/save_dispute_item") ?>',
        type: 'POST',
        data: data,
        dataType: 'json',
        success: function(res) {
          if (res.status === 'success') {
            alert('Dispute item saved!');
            $('#disputeModal').modal('hide');
          } else {
            alert('Error: ' + res.message);
          }
        },
        error: function() {
          alert('AJAX error. Please try again.');
        }
      });
    });
  });

  function loadDisputeItems() {
    $.ajax({
      url: '<?= base_url("Admin/get_dispute_items") ?>',
      method: 'GET',
      dataType: 'json',
      success: function(data) {
        const tbody = $('#dispute-table tbody');
        tbody.empty();

        if (data.length === 0) {
          tbody.html('<tr><td class="no-data" colspan="6">No dispute items added</td></tr>');
        } else {
          data.forEach(item => {
            const eqIcon = item.equifax == 1 ? '<img src="NEGATIVE_ICON_URL" height="25">' : '';
            const exIcon = item.experian == 1 ? '<img src="NEGATIVE_ICON_URL" height="25">' : '';
            const tuIcon = item.transunion == 1 ? '<img src="NEGATIVE_ICON_URL" height="25">' : '';

            tbody.append(`
            <tr>
              <td>${item.creditor_furnisher}</td>
              <td>
                ${item.equifax_account ? 'EQ: ' + item.equifax_account + '<br>' : ''}
                ${item.experian_account ? 'EX: ' + item.experian_account + '<br>' : ''}
                ${item.transunion_account ? 'TU: ' + item.transunion_account : ''}
              </td>
              <td>${item.dispute_reason}</td>
              <td>${eqIcon}</td>
              <td>${exIcon}</td>
              <td>${tuIcon}</td>
            </tr>
          `);
          });
        }
      }
    });
  }
</script> -->



<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
  $(document).ready(function() {
    $('.delete-dispute').click(function(e) {
      e.preventDefault();
      const id = $(this).data('id');

      Swal.fire({
        title: 'Are you sure?',
        text: 'This dispute item will be deleted.',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, delete it!',
        cancelButtonText: 'Cancel'
      }).then((result) => {
        if (result.isConfirmed) {
          $.ajax({
            url: '<?= base_url("Admin/delete_dispute_item") ?>',
            method: 'POST',
            data: {
              id
            },
            dataType: 'json',
            success: function(res) {
              if (res.status === 'success') {
                Swal.fire('Deleted!', 'Item removed.', 'success').then(() => {
                  location.reload(); // Refresh the table
                });
              } else {
                Swal.fire('Error!', 'Could not delete item.', 'error');
              }
            },
            error: function() {
              Swal.fire('Error!', 'AJAX failed.', 'error');
            }
          });
        }
      });
    });
  });
</script>



<script>
  $(document).ready(function() {

    function toggleAccountFields() {
      const sameForAll = $('#sameForAll').is(':checked');
      const differentForEach = $('#differentForEach').is(':checked');

      if (sameForAll) {
        $('#account_number_all').closest('.form-check').show();
        $('#equifax_account, #experian_account, #transunion_account').closest('.form-check').hide();
      }

      if (differentForEach) {
        $('#account_number_all').val('').closest('.form-check').hide();
        if ($('#equifax').is(':checked')) $('#equifax_account').closest('.form-check').show();
        if ($('#experian').is(':checked')) $('#experian_account').closest('.form-check').show();
        if ($('#transunion').is(':checked')) $('#transunion_account').closest('.form-check').show();
      }
    }

    $('#sameForAll, #differentForEach, #equifax, #experian, #transunion').change(function() {
      toggleAccountFields();
    });

    function loadDisputeItems() {
      $.ajax({
        url: '<?= base_url("Admin/get_dispute_items") ?>',
        type: 'GET',
        dataType: 'json',
        success: function(data) {
          const tbody = $('#dispute-table tbody');
          tbody.empty();

          if (data.length === 0) {
            tbody.append('<tr><td class="no-data" colspan="6">No dispute items added</td></tr>');
          } else {
            data.forEach(item => {
              const eqIcon = item.equifax == 1 ? '<img src="<?= base_url("downloads/simple_audit_images/negative.png") ?>" height="25">' : '';
              const exIcon = item.experian == 1 ? '<img src="<?= base_url("downloads/simple_audit_images/negative.png") ?>" height="25">' : '';
              const tuIcon = item.transunion == 1 ? '<img src="<?= base_url("downloads/simple_audit_images/negative.png") ?>" height="25">' : '';

              const accounts = [
                item.equifax_account ? 'EQ: ' + item.equifax_account : '',
                item.experian_account ? 'EX: ' + item.experian_account : '',
                item.transunion_account ? 'TU: ' + item.transunion_account : ''
              ].filter(Boolean).join('<br>');

              tbody.append(`
              <tr>
                <td>${item.creditor_furnisher}</td>
                <td>${accounts}</td>
                <td>${item.dispute_reason}</td>
                <td>${eqIcon}</td>
                <td>${exIcon}</td>
                <td>${tuIcon}</td>
              </tr>
            `);
            });
          }
        }
      });
    }

    // loadDisputeItems();

    $('.btn-success').click(function() {
      let hasError = false;
      $('.is-invalid').removeClass('is-invalid');

      // if ($('#creditor_furnisher').val() === "0") {
      //   $('#creditor_furnisher').addClass('is-invalid');
      //   hasError = true;
      // }

      if ($('#dispute_reason').val() === "0") {
        $('#dispute_reason').addClass('is-invalid');
        hasError = true;
      }

      if (!$('#equifax').is(':checked') && !$('#experian').is(':checked') && !$('#transunion').is(':checked')) {
        Swal.fire({
          icon: 'warning',
          title: 'Validation Error',
          text: 'Please select at least one bureau.'
        });
        hasError = true;
      }

      if (hasError) return;

      const data = {
        bureaus: {
          equifax: $('#equifax').is(':checked') ? 1 : 0,
          experian: $('#experian').is(':checked') ? 1 : 0,
          transunion: $('#transunion').is(':checked') ? 1 : 0
        },
        account_mode: $('input[name="accountNumber"]:checked').attr('id'),
        account_number_all: $('#account_number_all').val(),
        equifax_account: $('#equifax_account').val(),
        experian_account: $('#experian_account').val(),
        transunion_account: $('#transunion_account').val(),
        creditor_furnisher: $('#creditor_furnisher').val(),
        dispute_reason: $('#dispute_reason').val(),
        dispute_instruction: $('#dispute_instructions').val()
      };

      $.ajax({
        url: '<?= base_url("Admin/save_dispute_item") ?>',
        type: 'POST',
        data: data,
        dataType: 'json',
        success: function(res) {
          if (res.status === 'success') {
            Swal.fire({
              icon: 'success',
              title: 'Saved!',
              text: 'Dispute item saved successfully!',
              timer: 2000,
              showConfirmButton: false
            });
            $('#disputeModal').modal('hide');
            loadDisputeItems();
          } else {
            Swal.fire({
              icon: 'error',
              title: 'Error',
              text: res.message
            });
          }
        },
        error: function() {
          Swal.fire({
            icon: 'error',
            title: 'AJAX Error',
            text: 'Something went wrong. Try again.'
          });
        }
      });
    });
  });
</script>

<script>
  $('#btn-new-dispute').on('click', function() {
    $('#disputeModal').modal('show');
  });

  document.addEventListener('DOMContentLoaded', () => {
    const basic_dispute = document.getElementById('basic_dispute');
    const other_letters = document.getElementById('other_letters');
    const credit_bureau = document.getElementById('credit_bureau');
    const creditor_furnisher = document.getElementById('creditor_furnisher');
    const letterRecipientDiv = document.querySelector('.step-title + .radio-group');
    const step2Container = document.querySelector('#dispute-container:nth-of-type(2)');
    const recipientRadios = letterRecipientDiv.querySelectorAll('input[type="radio"]');

    // 1. Show/Hide "Choose Letter Recipient (Round 2 Only)" based on Round 2 selection
    basic_dispute.addEventListener('change', () => {
      if (basic_dispute.checked) {
        // letterRecipientDiv.style.display = 'block';
        $('.step-2').css('display', 'none');
      }
    });

    other_letters.addEventListener('change', () => {
      if (other_letters.checked) {
        // letterRecipientDiv.style.display = 'block';
        $('.step-2').css('display', 'block');
      }
    });

    // 2. Smooth scroll to Step 2 when selecting Round 1
    basic_dispute.addEventListener('click', () => {
      if (basic_dispute.checked) {
        scrollToStep2();
      }
    });

    credit_bureau.addEventListener('click', () => {
      if (credit_bureau.checked) {
        scrollToStep2();
      }
    });
    creditor_furnisher.addEventListener('click', () => {
      if (creditor_furnisher.checked) {
        scrollToStep2();
      }
    });

    // 3. Smooth scroll to Step 2 when selecting recipient after Round 2+ is selected
    // recipientRadios.forEach(radio => {
    //   radio.addEventListener('click', () => {
    //     if (other_letters.checked) {
    //       scrollToStep2();
    //     }
    //   });
    // });

    // Smooth scroll and highlight Step 2 container
    function scrollToStep2() {
      step2Container.scrollIntoView({
        behavior: 'smooth',
        block: 'start'
      });
      step2Container.style.border = '2px solid #007bff';

      // Remove border after 1 second
      setTimeout(() => {
        step2Container.style.border = 'none';
      }, 1000);
    }
  });
</script>