<?php echo "Client ID => ".$res["client_id"];

echo '<pre>';
print_r($res);
echo '</pre>';











 ?>


