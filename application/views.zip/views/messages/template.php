<?php

$this->load->view('subscriptions/include/header');
$this->load->view('subscriptions/include/navbar');
$this->load->view('subscriptions/include/sidebar');
$this->load->view($theme . '/' . $page);
$this->load->view('subscriptions/include/footer');
