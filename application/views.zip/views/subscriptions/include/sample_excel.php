<!DOCTYPE html>
<html>
  <head>
    <title>Hello, World!</title>
    <link rel="stylesheet" href="styles.css" />
  </head>
  <body>
      <table>
        <thead>
          <th class="excel-hide">Sno</th>
          <th>Key Word</th>
          <th>Values</th>
        </thead>
        <tbody>
          <tr>
            <td class="excel-hide">1</td>
            <td>lg_keys</td>
            <td>Keys</td>
          </tr>
          <tr>
            <td class="excel-hide">1</td>
            <td>lg_keys</td>
            <td>Keys</td>
          </tr>
          <tr>
            <td class="excel-hide">1</td>
            <td>lg_keys</td>
            <td>Keys</td>
          </tr>
          <tr>
            <td class="excel-hide">1</td>
            <td>lg_keys</td>
            <td>Keys</td>
          </tr>
        </tbody>
      </table>
  </body>
</html>