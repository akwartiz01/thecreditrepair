<?php

$user_type = $this->session->userdata('user_type');

$user_id = $this->session->userdata('user_id');
$fetch_user = $this->User_model->query("SELECT * FROM `sq_users` WHERE `sq_u_id` = '" . $user_id . "'");

if ($fetch_user->num_rows() > 0) {
  $fetch_user = $fetch_user->row();
} else {
  $fetch_user = [];
}

$date = date('Y-m-d');
$calendar = $this->User_model->query("SELECT * FROM sq_calender WHERE `start` >= '" . $date . "' ORDER BY start asc LIMIT 5");
if ($calendar->num_rows() > 0) {
  $calendar = $calendar->result();
} else {
  $calendar = [];
}

$leads = $this->User_model->query("SELECT * FROM sq_clients WHERE `sq_status` = 1 ORDER BY sq_client_id desc LIMIT 5");
if ($leads->num_rows() > 0) {
  $leads = $leads->result();
} else {
  $leads = [];
}


$user_id = $this->session->userdata('user_id');

// Fetch recent activities and count unread activities in one query
$this->db->select('*');
$this->db->from('notifications');
$this->db->where('receiver_id', $user_id);
$this->db->where('sender_id !=', $user_id);
$this->db->order_by('id', 'desc');
$recent_activity_query = $this->db->get();

$recent_activity = $recent_activity_query->result();

// Count unread notifications
$this->db->select('COUNT(*) AS unread_count');
$this->db->from('notifications');
$this->db->where('receiver_id', $user_id);
$this->db->where('sender_id !=', $user_id);
$this->db->where('read_status', 0);
$recent_activity_count_query = $this->db->get();

$recent_activity_count = $recent_activity_count_query->row()->unread_count;

$query = $this->User_model->query("SELECT * FROM `sq_secure_messages` WHERE `read_status` = 0 AND `recipient_type` = 'admin' AND `receiver_id` ='$user_id'");
$unread_message_count = $query->num_rows();

?>
<!DOCTYPE html>
<html lang="en">

<head id="sqhead">
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <title>CRX Credit Repair</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendors/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendors/css/vendor.bundle.base.css">
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendors/fullcalendar/fullcalendar.min.css">
  <!-- endinject -->
  <!-- Plugin css for this page -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendors/font-awesome/css/font-awesome.min.css" />
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendors/bootstrap-datepicker/bootstrap-datepicker.min.css">
  <!-- End plugin css for this page -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendors/summernote/dist/summernote-bs4.css">
  <!-- inject:css -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/vendors/datatables.net-bs4/dataTables.bootstrap4.css">
  <!-- endinject -->
  <!-- Layout styles -->
  <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/demo_3/style.css">
  <!-- End layout styles -->
  <link rel="shortcut icon" href="<?php echo base_url(); ?>assets/images/logo.png" />
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <!-- <link rel="stylesheet" href="/resources/demos/style.css"> -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

  <style>
    body {
      background-color: #f5f8fa;
    }

    .chrightboxinner-img i {
      font-size: 39px;
      color: #231f20;
    }

    div#order-listing_filter {
      display: none;
    }
.tox-silver-sink{
      display: none;
}
    div#order-listing_length {
      display: none;
    }

    table#order-listing a {

      color: #3972FC;
    }

    .loading {
      padding-top: 20%;
      padding-left: 50%;
      position: fixed;
      left: 0px;
      top: 0px;
      width: 100%;
      height: 100%;
      z-index: 9999;
      opacity: 0.9;
      background-color: rgba(7, 7, 7, 0.5);
    }

    div#DataTables_Table_0_filter {
      float: right;
    }

    @media screen and (max-width: 768px) {
      .horizontal-menu .top-navbar .navbar-brand-wrapper .navbar-brand img {

        height: 55px;
        min-width: 110px;
      }
    }

    .tox.tox-tinymce {
      width: 100% !important;
      height: 500px !important;
    }

    .custom-search-input {
      border-radius: 20px;
      padding: 10px 40px 10px 20px;
      font-size: 14px;
      position: relative;
    }

    .custom-search-input:focus {
      box-shadow: 0px 0px 10px rgba(0, 123, 255, 0.25);
      border-color: #007bff;
    }

    .input-group-text.search-icon {
      position: absolute;
      right: 15px;
      top: 50%;
      transform: translateY(-50%);
      border: none;
      background: transparent;
      color: #888;
      font-size: 18px;
      cursor: pointer;
    }

    .client-list-dropdown {
      position: absolute;
      background-color: #fff;

      border-radius: 4px;

      width: 250px;
      max-height: 200px;
      overflow-y: auto;
      box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
      z-index: 1000;
      margin-top: 5px;
    }

    .client-list-dropdown ul {
      list-style: none;
      padding: 0;
      margin: 0;
    }

    .client-list-dropdown li.client-item {
      padding: 10px 20px;
      cursor: pointer;
      border-bottom: 1px solid #f1f1f1;
    }

    .client-list-dropdown li.client-item:last-child {
      border-bottom: none;
    }

    .client-list-dropdown li.client-item:hover {
      background-color: #f8f9fa;
    }

    .client-list-dropdown li.no-clients {
      padding: 10px 20px;
      color: #999;
      text-align: center;
    }


    .swal2-icon.swal2-success.swal2-icon-show {
      margin-top: 25px !important;
    }

    .swal2-icon.swal2-warning.swal2-icon-show {
      margin-top: 25px !important;
    }

    .swal2-icon.swal2-info.swal2-icon-show {
      margin-top: 25px !important;
    }

    .swal2-icon.swal2-error.swal2-icon-show {
      margin-top: 25px !important;
    }

    select.form-control,
    select.asColorPicker-input,
    .dataTables_wrapper select,
    .jsgrid .jsgrid-table .jsgrid-filter-row select,
    .select2-container--default select.select2-selection--single,
    .select2-container--default .select2-selection--single select.select2-search__field,
    select.typeahead,
    select.tt-query,
    select.tt-hint {

      outline: 1px solid #d0d0d0 !important;
      color: #495057 !important;
    }

    /* Loader CSS s*/
    #loader {
      display: none;
      position: fixed;
      z-index: 9999;
      left: 50%;
      top: 50%;
      transform: translate(-50%, -50%);
    }

    .spinner {
      border: 16px solid #f3f3f3;
      border-top: 16px solid #3498db;
      border-radius: 50%;
      width: 120px;
      height: 120px;
      animation: spin 2s linear infinite;
    }

    @keyframes spin {
      0% {
        transform: rotate(0deg);
      }

      100% {
        transform: rotate(360deg);
      }
    }


    .horizontal-menu .top-navbar .navbar-brand-wrapper .navbar-brand img {

      height: 55px !important;

    }

    span.count-symbol.notification-count {
      position: absolute !important;
      top: -5px !important;
      right: -5px !important;
      background-color: red !important;
      color: white !important;
      border-radius: 50% !important;
      padding: 3px 6px !important;
      font-size: 12px !important;
      font-weight: 600 !important;

      width: 24px !important;
      height: 27px !important;
    }

    .toast-dark-info {
      background-color: #1c2331 !important;
      color: white !important;
      width: 350px !important;
    }

    .toast-dark-info .toast-message {
      white-space: nowrap !important;
      overflow: hidden !important;
      text-overflow: ellipsis !important;
    }

    .table th,
    .jsgrid .jsgrid-table th,
    .table td,
    .jsgrid .jsgrid-table td {

      border-top: 1px solid rgba(0, 0, 0, 0.12) !important;
    }

    #onboarding_date {
      color: rgb(136, 136, 136);
      font-size: 13px;
      font-style: italic;
    }

    #onboarding_stage_login {
      font-style: italic;
    }

    #onboarding_stage_agreement {
      text-decoration: underline;
      font-style: italic;
      text-decoration-color: #3972fc;
    }

    #range_chart {
      margin-top: 30px;
    }

    .highcharts-credits {
      display: none;
    }


    .container-scroller .content-wrapper {
      max-width: 100% !important;
    }


    .progress-container {
      display: flex;

      justify-content: space-between;
      margin: 20px auto;
      max-width: 800px;
      padding: 0 10px;
    }

    .progress-step {
      text-align: center;
      position: relative;
      flex: 1;
    }

    .progress-step .circle {
      width: 40px;
      height: 40px;
      background: lightgray;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto;
      font-size: 18px;
      font-weight: bold;
      color: #333;
      position: relative;
      z-index: 2;
    }

    .progress-step.completed .circle {

      background: rgb(129, 205, 243);
      color: white;
    }

    .progress-step .text {
      margin-top: 10px;
      font-size: 14px;
      color: #666;
    }

    .progress-step.completed .text {
      font-family: Arial, Helvetica, sans-serif;

      color: rgb(129, 205, 243);
    }

    .progress-line {
      position: absolute;
      height: 3px;
      background: lightgray;
      top: 20px;
      left: 50%;
      right: -50%;
      z-index: 1;
    }

    .progress-step.completed.progress-step .progress-line {

      background: rgb(129, 205, 243);
    }

    .progress-arrow {
      position: absolute;
      top: 26%;
      right: -10px;
      transform: translateY(-50%);
      width: 0;
      height: 0;
      border-top: 10px solid transparent;
      border-bottom: 10px solid transparent;
      border-left: 10px solid rgb(129, 205, 243);
      z-index: 3;
    }

    .progress-step:not(:last-child) .progress-arrow {
      display: block;
    }

    .progress-step:not(.completed) .progress-arrow {
      border-left-color: lightgray;
    }

    .card-group {
      margin-top: 20px;
    }

    .card-body {
      padding: 20px;
    }

    .navigation-buttons {
      background-color: #f9f9f9;
      border: 1px solid #e0e0e0;
      padding: 10px 20px;
      border-radius: 8px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      transition: all 0.3s ease;
      display: flex;
      align-items: center;
      gap: 8px;
      font-weight: 500;
    }

    .navigation-buttons i {
      font-size: 16px;
    }

    .navigation-buttons:hover {
      background-color: #e9f5e9;
      box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
      transform: translateY(-2px);
    }
  </style>

</head>

<body>

  <div id="loader">
    <img src="<?php echo base_url('assets/loading-gif.gif'); ?>" style="height: 50px;" alt="Loading..." class="loader-image">
  </div>

  <div class="container-scroller">

    <div class="horizontal-menu">


      <nav class="navbar top-navbar col-lg-12 col-12 p-0">
        <div class="container" style="max-width: 100% !important;">
          <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
            <a class="navbar-brand brand-logo" href="<?php echo base_url(); ?>"><img src="<?php echo base_url(); ?>assets/images/logo.png" alt="logo"></a>
            <a class="navbar-brand brand-logo-mini" href="<?php echo base_url(); ?>"><img src="<?php echo base_url(); ?>assets/images/logo.png" alt="logo"></a>
          </div>
          <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end">

            <ul class="navbar-nav navbar-nav-right">

           <li class="nav-item dropdown" data-toggle="tooltip" data-placement="top" title="Recent Login Activity">
  <a class="nav-link count-indicator dropdown-toggle" id="messageDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
    <i class="mdi mdi-bell" style="font-size: 24px; color: #333;"></i>
    <?php if (!empty($recent_activity_count)): ?>
      <span class="count-symbol notification-count" id="notification-count"><?php echo $recent_activity_count; ?></span>
    <?php endif; ?>
  </a>
  <div class="dropdown-menu dropdown-menu-right navbar-dropdown preview-list" aria-labelledby="messageDropdown" style="width: 400px; max-height: 300px; overflow-y: auto;">
    <h6 class="p-3 mb-0">Recent Login Activity</h6>
    <div class="dropdown-divider"></div>

    <?php if (!empty($recent_activity)): ?>
      <?php foreach ($recent_activity as $activity): ?>
        <?php
          $query = $this->db->get_where('sq_users', ['sq_u_id' => $activity->sender_id]);
          $user = $query->row();
          if ($user):
            $img = !empty($user->sq_u_profile_picture) ? $user->sq_u_profile_picture : base_url('assets/img/user.jpg');
        ?>
          <a class="dropdown-item preview-item">
            <div class="preview-thumbnail">
              <img src="<?php echo $img; ?>" alt="image" class="profile-pic">
            </div>
            <div class="preview-item-content d-flex align-items-start flex-column justify-content-center">
              <h6 class="preview-subject ellipsis mb-1 font-weight-normal">
                <?php echo $user->sq_u_first_name . ' ' . $user->sq_u_last_name; ?>
              </h6>
              <p class="text-gray mb-0 text-truncate" style="max-width: 300px;">
                <?php echo substr($activity->msg, 0, 50) . '...'; ?>
                <br><small><?php echo $activity->created_at; ?></small>
              </p>
            </div>
          </a>
          <div class="dropdown-divider"></div>
        <?php endif; ?>
      <?php endforeach; ?>
    <?php else: ?>
      <p class="text-center text-gray p-3 mb-0">No recent activity</p>
    <?php endif; ?>

    <h6 class="p-3 mb-0 text-center"><a href="<?php echo base_url('allactivity'); ?>">See all activities</a></h6>
  </div>
</li>


              <li class="nav-item dropdown" data-toggle="tooltip" data-placement="top" title="New Leads">
                <a class="nav-link count-indicator dropdown-toggle" id="messageDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
                  <i class="mdi mdi-account-multiple menu-icon" style="font-size: 24px; color: #333;"></i>

                </a>
                <div class="dropdown-menu dropdown-menu-right navbar-dropdown preview-list" aria-labelledby="messageDropdown" style="width: 400px !important;">
                  <h6 class="p-3 mb-0">New Leads</h6>
                  <div class="dropdown-divider"></div>
                  <?php
                  if (!empty($leads)) {
                    foreach ($leads as $key => $lead_value) {

                      if (!empty($lead_value->profile_img)) {
                        $img_leads = $lead_value->profile_img;
                      } else {
                        $img_leads = base_url('assets/assets/img/user.jpg');;
                      }

                      $affiliates = $this->User_model->query("SELECT * FROM sq_affiliates WHERE `sq_affiliates_id` ='" . $lead_value->sq_referred_by . "'");
                      if ($affiliates->num_rows() > 0) {
                        $affiliates = $affiliates->result();
                      }

                  ?>
                      <a class="dropdown-item preview-item" href="<?php echo base_url(); ?>edit-client/<?php echo base64_encode(base64_encode($lead_value->sq_client_id)); ?>">
                        <div class="preview-thumbnail">
                          <img src="<?php echo $img_leads; ?>" alt="image" class="profile-pic">
                        </div>
                        <div class="preview-item-content d-flex align-items-start flex-column justify-content-center">
                          <h6 class="preview-subject ellipsis mb-1 font-weight-normal"><?php echo $lead_value->sq_first_name . ' ' . $lead_value->sq_last_name; ?></h6>
<p class="text-gray mb-0">
    Referred by: <?php echo $affiliate->sq_affiliates_first_name . ' ' . $affiliate->sq_affiliates_last_name; ?>
</p>
                        </div>
                      </a>
                      <div class="dropdown-divider"></div>
                  <?php }
                  } ?>

                  <h6 class="p-3 mb-0 text-center"><a href="<?php echo base_url('clients'); ?>">See all leads</a></h6>
                </div>
              </li>

              <li class="nav-item dropdown" data-toggle="tooltip" data-placement="top" title="New Messages" id="chat_list">
                <a class="nav-link count-indicator dropdown-toggle" id="messageDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
                  <i class="mdi mdi-comment" style="font-size: 24px; color: #333;"></i>
                  <?php if ($unread_message_count > 0): ?>
                    <span class="count-symbol notification-count"><?php echo $unread_message_count; ?></span>
                  <?php endif; ?>
                </a>
              </li>

              <li class="nav-item dropdown" data-toggle="tooltip" data-placement="top" title="My Tasks & Events">
                <a class="nav-link count-indicator dropdown-toggle" id="notificationDropdown" href="#" data-toggle="dropdown">
                  <i class="mdi mdi-calendar-check" style="font-size: 24px; color: #333;"></i>

                </a>
                <div class="dropdown-menu dropdown-menu-right navbar-dropdown preview-list" aria-labelledby="notificationDropdown" style="width: 400px !important;">
                  <h6 class="p-3 mb-0">My Tasks & Events</h6>
                  <div class="dropdown-divider"></div>
                  <?php
                  if (!empty($calendar)) {
                    foreach ($calendar as $key => $value) {

                      $event_date = '';
                      $tomorrow = date('Y-m-d', strtotime('+1 day'));

                      if ($date == $value->start) {
                        $event_date = 'Today';
                      } elseif ($tomorrow == $value->start) {
                        $event_date = 'Tomorrow';
                      } else {
                        $event_date = $value->start;
                      }

                  ?>
                      <a class="dropdown-item preview-item" href="<?php echo base_url('schedule'); ?>">
                        <div class="preview-thumbnail">
                          <div class="preview-icon bg-success">
                            <i class="mdi mdi-calendar"></i>
                          </div>
                        </div>
                        <div class="preview-item-content d-flex align-items-start flex-column justify-content-center">
                          <p class="text-gray ellipsis mb-0"><?php echo $value->title; ?></p>
                          <p class="text-gray mb-0"><?php echo $event_date; ?></p>
                        </div>
                      </a>
                      <div class="dropdown-divider"></div>
                  <?php }
                  } ?>

                  <h6 class="p-3 mb-0 text-center"><a href="<?php echo base_url('schedule'); ?>">See all notifications</a></h6>
                </div>

              </li>



              <li class="nav-item nav-logout d-none d-lg-flex" data-toggle="tooltip" data-placement="top" title="Logout">
                <a class="nav-link" href="javascript:void(0);" onclick="confirmLogout()">
                  <i class="mdi mdi-power" style="font-size: 24px; color: #333;"></i>
                </a>
              </li>

              <li class="nav-item nav-search d-none d-lg-block" style="margin-left: 0px !important;">
                <div class="input-group">

                  <input type="text" class="form-control custom-search-input" id="navbar-search-input" placeholder="Search..." aria-label="search" aria-describedby="search" style="border: 2px solid #3972FC; border-radius:2px; padding:10px;">
                  <span class="input-group-text search-icon" id="search">
                    <i class="mdi mdi-magnify"></i>
                  </span>
                </div>
                <div id="clientList" class="client-list-dropdown"></div>
              </li>

            </ul>

            <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="horizontal-menu-toggle"><span class="mdi mdi-menu"></span></button>

          </div>
        </div>
      </nav>
      <nav class="bottom-navbar">
        <div class="container" style="max-width: 1280px !important;">
          <ul class="nav page-navigation">

            <!-- *** HOME TAB *** -->
            <?php if (check_permisions("home", "view")) { ?>
              <li class="nav-item mega-menu">
                <a href="<?php echo base_url(); ?>" class="nav-link">
                  <i class="mdi mdi-home menu-icon" style="margin-right: 3px!important;"></i>
                  <span class="menu-title">Home</span>
                </a>

              </li>
            <?php  } ?>
            <!-- *** END HOME TAB *** -->

            <?php if (check_permisions("client", "view")) { ?>
              <li class="nav-item mega-menu">
                <a href="<?php echo base_url(); ?>clients" class="nav-link">
                  <i class="mdi mdi-account-multiple menu-icon" style="margin-right: 3px!important;"></i>
                  <span class="menu-title">Clients</span>
                </a>

              </li>
            <?php  } ?>

            <?php if (check_permisions("client", "view")) {
              if ($user_type != 'subscriber') { ?>
                <li class="nav-item mega-menu">
                  <a href="<?php echo base_url(); ?>plans" class="nav-link">
                    <i class="mdi mdi-cash-multiple menu-icon" style="margin-right: 3px!important;"></i>
                    <span class="menu-title">Plans</span>
                  </a>

                </li>
            <?php }
            } ?>

            <?php if (check_permisions("schedule", "view")) {
              if ($user_type == 'subscriber') { ?>

                <li class="nav-item">
                  <a class="nav-link" href="<?php echo base_url(); ?>manage-subscriptions">
                    <i class="mdi mdi-calendar-clock menu-icon" style="margin-right: 3px!important;"></i>
                    <span class="menu-title">Manage Subscriptions</span>
                  </a>
                </li>
            <?php }
            } ?>


            <?php if (check_permisions("schedule", "view")) { ?>
              <li class="nav-item">
                <a class="nav-link" href="<?php echo base_url(); ?>schedule">
                  <i class="mdi mdi-calendar-clock menu-icon" style="margin-right: 3px!important;"></i>
                  <span class="menu-title">Schedule</span>
                </a>
              </li>
            <?php } ?>

            <?php if (check_permisions("company", "view")) { ?>
              <li class="nav-item">
                <a href="<?php echo base_url() ?>my-company" class="nav-link">
                  <i class="mdi mdi-home-map-marker menu-icon" style="margin-right: 3px!important;"></i>
                  <span class="menu-title">My Company</span>
                </a>
              </li>
            <?php } ?>

            <?php if (check_permisions("library", "view")) { ?>
              <li class="nav-item mega-menu">
                <a href="<?php echo base_url() ?>templates" class="nav-link">
                  <i class="mdi mdi-library menu-icon" style="margin-right: 3px!important;"></i>

                  <span class="menu-title">Letter Library</span>
                </a>
              </li>
            <?php } ?>


            <?php if (check_permisions("affiliate", "view")) { ?>
              <li class="nav-item">
                <a href="<?php echo base_url(); ?>affiliates" class="nav-link">
                  <i class="mdi mdi-webpack menu-icon" style="margin-right: 3px!important;"></i>
                  <span class="menu-title">Affiliate</span>
                </a>
              </li>
            <?php } ?>

            <?php if (check_permisions("creditor", "view")) { ?>
              <li class="nav-item">
                <a href="<?php echo base_url(); ?>furnisher" class="nav-link">
                  <i class="mdi mdi-file-document-box menu-icon" style="margin-right: 3px!important;"></i>
                  <span class="menu-title">Creditor Furnisher</span></a>
              </li>
            <?php } ?>


          </ul>
        </div>
      </nav>
    </div>